#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "hide64.h"


int hideloadfile (char* file)
{
	static unsigned i;
	//static unsigned char c;
	static char* a=0xD000;
	//a=0xD000;
	i=cbm_open (3,8,CBM_READ,file);
	//puts ("About to load file...."); cgetc();
	//if (i!=0) {printf ("Error #%d loading file.\n",i); cgetc();}
	cbm_k_chkin (3);
	//for (i=0; !cbm_k_readst(); ++i)
	while (!cbm_k_readst())
	{
		//if (cbm_read (3,&c,1)<=0) break;
		//cbm_read (3,&c,1);
		hidewriteb (a++, cbm_k_basin()); 
		//*((char*)a++)=c;
		//*((char*)1024)=c;
		//if (a>=1040) break;
		//putchar (c);
	}
	cbm_k_clrch();
	cbm_close(3);
	return 0;
}


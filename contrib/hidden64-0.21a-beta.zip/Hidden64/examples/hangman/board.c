/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c64.h>
#include "hide64.h"

#include "words.h"

//Put board information in the tape buffer to save space in main RAM.
#pragma bssseg (push, "TAPEBSS")
unsigned curboardnum;		//Number of current board, defined elsewhere.
char board [3][32];		//Board, as on screen, in PETSCII.
unsigned long lettersused;	//Letters called, bit 0=A, bit 1=B, etc.
unsigned long lettersinboard;	//Letters in the board.
unsigned char turnsleft;
//Temp. board data.
struct boards curboard;

//Reads and draws the board on the screen, board # passed in b.
void drawboard (unsigned b)
{
	// Current word to write to board.
	static char line[33];
	// Pos. in board text.
	static char* cpos;
	//Currently read character from board.
	static char c;
	// Pos. in line.	
	//unsigned char lpos=0;
	static unsigned char lpos;
	// Coordinates on board.
	//unsigned char x=0, y=0;
	static unsigned char x, y;
	x=y=lpos=0;
	//Set board #.
	curboardnum=b;
	//Read board data from hidden memory for easier access.
	hmemcpy (&curboard, &boards[b], sizeof(struct boards));
	//Read address of board data to accomodate 
	cpos=curboard.board;

	//Display the game header (category, level).
	printf ("\f\x12\x1e""%-34.34Hs Lvl %d\x92\x81", 
		hidereadw((void*)&catetext[curboard.cate]),
		curboard.level);
	//Draw an orange line just below the space for the board.
	//textcolor (8);
	chlinexy (0,5,39);

	//Set the board screen to all spaces.
	memset (board, 32, 96);

	//Process board:
	for (; c=hidereadb(cpos); ++cpos) //Read char.
	{
		//If letter or number:
		if (isalnum(c)) {
			//add to line (word)
			line[lpos++]=c;
			//and move to next line if overflow.
			if (x+lpos>=32){
				++y; x=0;
			}
		//If space:
		} else if (c==' '){
			//copy word to board
			memcpy (&board[y][x], line, lpos);
			//and reset line for next word.
			x+=lpos+1; lpos=0;
		}
	}
	//Copy last line to board.
	memcpy (&board[y][x], line, lpos);

	//Clear letters called and letters in the puzzle.
	lettersused=lettersinboard=0;
	//Scan board.
	for (y=0; y<3; ++y) {
		//Set write co-ordinates to beginning of current line.
		gotoxy (5,y+1);
		//Scan line.
		for (x=0; x<32; ++x) {
			//Read char. in board.
			c=board[y][x];
			//If letter:
			if (isalpha (c)) {
				//print space for letter
				textcolor (12);
				cputc ('_');
				 //and add letter to letters in board.
				lettersinboard|=(unsigned long) 1<<(c-'a');
			//Otherwise (i.e space), write char.
			} else {
				textcolor (2);
				cputc (c);
			}
		}
	}
	//Write turns left in black.
	textcolor (0);
	cputsxy (0,12,"10 turns left");
	//Write call letters just under board line.
	textcolor (3);
	revers (1);
	gotoxy (0,6);for (x='a'; x<(26+'a'); ++x) cputc (x);
	revers (0);
	//Write turns left.
	turnsleft=10;
}

//Routine to process letter guessed.  l=PETSCII letter.
//Returns 0 for good, 1 for win, 2 for letter already called and 3 for lose.
unsigned char guessletter (char l)
{
	static unsigned char x, l2;
	//Get letter # (a=0, b=1, etc.).
	l2=l-'a';
	//Mark letter on screen as called.
	cputcxy (l2,6,' ');
	//If letter already called, letter already called.
	if ((lettersused>>l2)&1) return 2;
	//Mark letter as called.
	lettersused|=(unsigned long) 1<<l2;
	//If letter in board, 
	if ((lettersinboard>>l2)&1) {
		//set text to orange,
		textcolor (8);
		//scan board
		for (x=0; x<96; ++x)
			//and print every occurence of the letter to the screen.
			if (board[x>>5][x&31]==l) cputcxy ((x&31)+5, (x>>5)+1, l);
		//If all letters called, Win!
		if ((lettersinboard&lettersused)==lettersinboard) return 1;
		//Otherwise, good.
		return 0;
	}
	//If letter not in board, lose turn
	--turnsleft;
	//and write turns left.
	gotoxy (0,12); printf ("%2.2d", (unsigned) turnsleft);
	//If over, flag.
	if (!turnsleft) return 3;
	//If turns left, return bad choice.
	return 2;
}

#pragma bssseg (pop)



#ifndef _RANDFADE_H
#define _RANDFADE_H
	void randfade(unsigned char whichchar, unsigned char color);
#endif

/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c64.h>
#include "hide64.h"

#include "board.h"

//Stores messages used by the program to demonstrate the use of hidden
//memory to store program text.  In board.h is an enum named message
//that holds the subscripts for this array as viewed by the program.
char* Message[]={
//Empty, reserved for program introduction.
	"",
//Get category.
	"\f\x81"
	"Hangman Hidden64 by Joseph Rose, a.k.a.\n"
	"Harry Potter.\n"
	"---------------------------------------\n"
	"Please select puzzle category, or X to\n"
	"cancel:\n"
};

#pragma rodataseg ("HIDECONST")

/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c128.h>
#include <membank128.h>


#include <menus.h>

#pragma data-name ("APPDATA")
#pragma rodata-name ("APPCONST")

char* mtext[] =
{
	"Input data",
	"Load data from disk",
	"Save data to disk",
	"List vocabulary",
	"Write randmized brainstoms",
	"Exit"
};

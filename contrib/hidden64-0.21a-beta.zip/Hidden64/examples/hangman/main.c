/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c64.h>
#include "hide64.h"

#include "board.h"
#include "words.h"

void main ()
{
	//Load the hidden RAM stub containing some of the text.
	hideloadfile ("hanghi,s");
	//Set screen colors.
	bordercolor (COLOR_CYAN);
	bgcolor (COLOR_WHITE); 
	//Randomize seed for random puzzle.
	_randomize();
	//Play the game.  (Routine in player.c)
	play();
}


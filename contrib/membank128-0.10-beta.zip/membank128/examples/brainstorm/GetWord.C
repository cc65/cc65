/**************************************************************************
 *
 * Individual C module created by TempC Small for DOS.
 *
 * The end-user may use this code as he/she likes under the following
 * conditions:
 *
 * 1. TempC, along with its author, is mentioned in the program's 
 *    documentation, and
 * 2. If this source code is published, this header must be kept
 *    intact.
 *
 **************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <c128.h>
#include "membank128.h"
#include <conio.h>
#include "dialog.h"
#include "menus.h"

#include "env.h"
#pragma bss-name (push, "TAPEBSS")

struct word tmpw;
struct numparts numparts;
#pragma data-name (push, "APPDATA")
unsigned numwords=0;
#pragma data-name (pop)

#pragma bss-name (pop)
struct word words [wordslimit];
extern field fWord, fSpeech;
extern fldenv dia;
#pragma code-name ("APPCODE")

#pragma bss-name ("TAPEBSS")

void GetWordEntry()
{
	static unsigned char c,d;
	static int i;
	c=0;
	fWord.data.text=tmpw.word;
	fSpeech.data.sel.sel=(unsigned*)&tmpw.s;
	fSpeech.data.sel.num=4;
	fSpeech.data.sel.values=speechtext;
	//Set screen colors:
	bordercolor(COLOR_VIOLET); bgcolor(COLOR_WHITE);
	while (1) {
backcall:
		//
		clrscr();
		if (numwords>=wordslimit) {
			puts (	"\x93Out of memory for words.\n"
				"Press any key to continue...");
			cgetc();
			return;
		} else if (numwords>=wordslimit-12) {
			puts (	"\x93You are running out of memory for words.\n"
				"Continue anyway (Y/N)?");
			if (cgetc()!='y') return;
			
		}
		if (c==0) //bzero (&tmpw, sizeof(tmpw));
			memset (&tmpw,0,sizeof(tmpw));
		if (!(c=dialog(&dia))) return;
		if (!tmpw.word[0]) return;
		for (i=0; i<numwords; ++i) {
			if (!strcmp(words[i].word, tmpw.word) &&
				//!strcmp(words[i].desc, tmpw.desc) &&
				words[i].s==tmpw.s)
			{
				DrawField (0,22,78,"This word is already defined as such.");
				DrawField (0,23,78,"Do you want to retry (Y/N)?");
				while (1) {
					d=cgetc();
					if (d=='y') {c=1; goto backcall;}
					if (d=='n') {c=0; goto backcall;}
				}
			}
		}
		switch (tmpw.s) {
		case 0: ++numparts.nouns; break;
		case 1: ++numparts.verbs; break;
		case 2: ++numparts.adj; break;
		case 3: ++numparts.adv; break;
		}
		memcpy (&words[numwords++], &tmpw, sizeof(tmpw));
		DrawField (0,22,78,"The word has been added to the database.");
		DrawField (0,23,78,"Input another (Y/N)?");
		
		while (1) {
			d=cgetc();
			if (d=='y') {c=0; goto backcall;}
			if (d=='n') {return;}
		}
	}
}

#pragma rodata-name ("APPCONST")

unsigned char __fastcall__ sqrt16(unsigned int arg);
unsigned char __fastcall__ sqrt8(unsigned char arg);

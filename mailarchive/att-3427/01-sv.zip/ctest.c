#include "supervision.h"

static char Text[]="Hello World";

void nmi(void)
{
  sv_video[0]=sv_video[0]+1;
}

int main(void)
{
  nmi_vector=nmi;
  //  sv_bank(false, false, false, true, false, 0);
  sv_bank(true, false, false, true, false, 0);
  sv_lcd->width=0xa0;
  sv_lcd->height=0xa0;
  sv_lcd->xpos=sv_lcd->ypos=0;

  
  for (;;) sv_video[0x31]=sv_video[0x31]+1;

  return 0;
}

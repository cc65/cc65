#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
//#include <ctype.h>

#include <c128.h>
#include "dialog.h"
#include "membank128.h"
#include "env.h"

extern unsigned char menucolor, menuhicolor;

/*void __fastcall__ pause ()
{
	puts ("Press any key to continue...");
	cgetc();
}*/
#pragma bss-name ("TAPEBSS")

char __fastcall__ GetInput (char* In, char InLen)
{
	static unsigned char c;
	static char CurPos;
	CurPos=0;

	textcolor (4);
	putchar ('>');
	while (1)
	{
		cursor (1);
		c = cgetc ();
		cursor (0);

		if (c==13){ /*return*/
			In[CurPos]=0;
			putchar ('\n');
			textcolor (8);
			return CurPos;
		} else if (c == 20 && CurPos > 0) { /* delete */
			--CurPos;
			putchar (20);
		} else if ((c&0xE0) && CurPos<InLen) {
			In[CurPos++]=c;
			putchar (c);
		}
	}
}


void main()
{
	//cbm_k_setbnk (0,0);
	puts ("\x93\x9CLoading stub...");
	cbm_load ("bstmlow", 8,0);
	puts ("Stub loaded!");
	puts ("Please switch to 80-column mode now!");
	videomode (VIDEOMODE_80COL);
	memset (&numparts, 0, sizeof(numparts));
	//__Columns=79;
	bgcolor (1);
	//menucolor=2; menuhicolor=13;
	//numwords=0;
	while (1)
	{
		switch (MainMenu())
		{
		case mnuIn:
			GetWordEntry();
			break;
		case mnuLoad:
			file_load ();
			break;
		case mnuSave:
			file_save ();
			break;
		case mnuList:
			ListWords();
			break;
		case mnuWriteR:
			brainstorm ();
			break;
		case mnuExit:
		case 0xFF:
			gotoxy (0, 18);
			puts (	//"\x93"
				"\x90Thank you for using my program.  I hope you had fun!\n"
				"--- \x9AJoseph Rose\x93, a.k.a. \x9BHarry Potter\x93.");
			chline (78);
			//putchar (13);
			return;
		}
	}
}

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

char text[]="Harry Potter Demo!";

char line[2][18];

char col[18]={2,7,5,3,6,4,2,7,5,3,6,4,2,7,5,3,6,4};

static void lineclr(unsigned char l)
{
	unsigned char i=0;
	textcolor (0);
	for (; i<18; ++i)
		cputcxy (i,line[l][i], 32);
}

static void linewrite(unsigned char l)
{
	unsigned char i=0;
	for (; i<18; ++i) {
		textcolor (col[i]);
		cputcxy (i,line[l][i], text[i]);
	}
}

void main()
{
	//unsigned char curpage=0;
	signed char incr=-1;
	unsigned i;

	memset(line,22,18<<1);
	bgcolor (1);
	bordercolor (1);
	textcolor (0);
	clrscr();
	puts   ("Text Demo 1 by Harry\n"
		"Potter.  Press any key"
		"to continue...");
	cgetc();

	_randomize();


	clrscr();

	while (1)
	{
		lineclr(0);
		linewrite(1);
		//curpage^=1;
		memcpy (line[0],
			line[1], 18);
		memmove (&line[1][0], &line[1][1],17);
		if	((incr==-1&&line[0][17]==0) ||
			(incr==1&&line[0][17]==22))
			incr=-incr;
		else if ((rand()&7)==0)
			incr=-incr;
		line[1][17]+=incr;
		for (i=0;i<8192;i++);
	}
}
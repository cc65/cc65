#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include <c64.h>

int tblSin [256];
int tblSQR [256];

//Store table build code in Bank 3.
#pragma codeseg		("CODE4")
#pragma rodataseg	("RODATA4")

//PI, where 1=64k:
static const long pi = 0x3243F;


int isin (long radians)
{
	register unsigned i=1;
	static long tmp, cur;
	static long numer, denom;
	tmp=cur=numer=denom=0;
	for (i=1; ;i+=2) {
		numer*=numer;
	}
}

static void sin ()
{
	static long i; register int l;
	
}
void buildtbl ()
{
	register long i;
};



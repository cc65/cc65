#ifndef __dirmenu_menu_H
#define __dirmenu_menu_H

#ifdef __CBM__
#define lenfilename 16
#endif
#ifdef __VIC20__
#define maxfiles 18
#define __Columns__ 22
#define __Rows__ 23
#elif defined __C16__
#define maxfiles 20
#define __Columns__ 40
#define __Rows__ 25
#elif defined __APPLE2__ || defined __APPLE2ENH__
#define maxfiles 40
#define lenfilename 12
#define __Columns__ 40
#define __Rows__ 24
#else
#define maxfiles 40
#define __Columns__ 40
#define __Rows__ 25
#endif
extern char prg[17];

void SelPrg ();
#endif

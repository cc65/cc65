#ifndef _KICKB_H_
#define _KICKB_H_
	void kickborder(void);
	
#endif
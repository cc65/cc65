// File        : main.c
// Version     : 0.0
// Description : example kernel for cc65 on Atari 2600 VCS
// Author      : Adam Wozniak <adam@cuddlepuddle.org>
// Date        : Tue Mar 26 18:04:32 PST 2002
// 
// This file is part of cc65-a2600lib.
// 
// cc65-a2600lib is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cc65-a2600lib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Foobar; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#include "tia.h"
#include "riot.h"

void kernel(unsigned char i)
{
   unsigned char j;

   // turn everything the same color
   TIA.COLUP0 = TIA.COLUP1 = TIA.COLUPF = TIA.COLUBK = i;

   TIA.WSYNC=1; // wait for sync

   // 3 lines vsync
   TIA.VSYNC = 0xff;
   TIA.WSYNC=1; // wait for sync
   TIA.WSYNC=1; // wait for sync
   TIA.WSYNC=1; // wait for sync
   TIA.VSYNC = 0x00;

   // 37 lines vertical blank
   TIA.VBLANK = 0xff;
   for (j = 0; j < 37; j++)
   {
      TIA.WSYNC=1; // wait for sync
   }
   TIA.VBLANK = 0x00;

   // visible screen
   for (j = 0; j < 192; j++)
   {
      TIA.WSYNC=1; // wait for sync
   }

   // overscan area
   for (j = 0; j < 30; j++)
   {
      TIA.WSYNC=1; // wait for sync
   }
}

void main(void)
{
   unsigned int i;

   // turn that damn noise off
   TIA.AUDV0 = 0;
   TIA.AUDV1 = 0;

   while (1)
   {
      i++;

      kernel(i & 0xff);
   }

   exit();
}

void irq(void)
{
}

void nmi(void)
{
}

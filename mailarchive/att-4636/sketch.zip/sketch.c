// A silly application that allows you to draw pixels around the screen.
// Change colors with Fire 2 (in case your driver supports a second fire
// button).
// Keeping Fire pressed works as an eraser.

#ifdef __APPLE2__
#include <apple2.h>
#endif
#ifdef __APPLE2ENH__
#include <apple2enh.h>
#endif
#ifdef __C128__
#include <c128.h>
#endif
#ifdef __C64__
#include <c64.h>
#endif
#ifdef __GEOS__
#include <geos.h>
#endif
#ifdef __LYNX__
#include <lynx.h>
#endif
#include <6502.h>
#include <joystick.h>
#include <tgi.h>

extern char minijoy[];
extern char minitgi[];

char drawPending;

#define DELAY 900

void
usleep(int n)
{
    int i;
    for (i = 0; i < n; i++)
	;
}

void main(void)
{
  int x, y, w, h, frame;
  unsigned char color, nrofcolors, background, framecolor;

#ifdef COLOR_RED
  framecolor = COLOR_RED;
#else
  framecolor = COLOR_BLACK;
#endif

#ifdef COLOR_GREY
  background = COLOR_GREY;
#else
  background = COLOR_WHITE;
#endif

  // Set up the modules
  CLI();
  tgi_install(&minitgi);
  nrofcolors = tgi_getcolorcount();
  w = tgi_getxres();
  h = tgi_getyres();
  joy_install(&minijoy);

  // Single display buffer
  tgi_setviewpage(0);
  tgi_setdrawpage(0);

  // Set our default palette to the hardware
  tgi_setpalette(tgi_getdefpalette());

  // Draw an Etch-A-Scetch style background
  tgi_setcolor(framecolor);
  tgi_bar(0, 0, w-1, h-1);
  tgi_setcolor(background);
  frame = h / 8;
  tgi_bar(frame, frame, w-frame-1, h-frame-1);

  // Set our pen to the center
  x = w / 2;
  y = h / 2;
  color = COLOR_BLACK;

  // Start our application
  drawPending = 0;
  while (1) {
    unsigned char eraser;
    unsigned char joy;
    unsigned char oldcolor;
    joy = joy_read(JOY_1);
    if (JOY_BTN_UP(joy)) {
      y--;
      if (y < frame + 1)
	y = frame + 1;
      drawPending = 1;
    }
    if (JOY_BTN_DOWN(joy)) {
      y++;
      if (y > h - frame - 2)
	y = h - frame - 2;
      drawPending = 1;
    }
    if (JOY_BTN_LEFT(joy)) {
      x--;
      if (x < frame + 1)
	x = frame + 1;
      drawPending = 1;
    }
    if (JOY_BTN_RIGHT(joy)) {
      x++;
      if (x > w - frame - 2)
	x = w - frame - 2;
      drawPending = 1;
    }
    if (JOY_BTN_FIRE(joy)) {
      eraser = 1;
      drawPending = 1;
    } else {
      eraser = 0;
    }
#ifdef JOY_FIRE2
    if (JOY_BTN_FIRE2(joy)) {
      drawPending = 1;
      color++;
      if (color > nrofcolors)
          color = 0;
    }
#endif
    if (drawPending) {
      if (eraser) {
        tgi_setcolor(background);
        tgi_bar(x-1, y-1, x+1, y+1);
      } else {
        tgi_setcolor(color);
        tgi_setpixel(x, y);
      }
      drawPending = 0;
    }
    // Blink cursor
    oldcolor = tgi_getpixel(x, y);
    tgi_setcolor(oldcolor ^ (nrofcolors - 1));
    tgi_setpixel(x, y);
    usleep(DELAY);
    tgi_setcolor(oldcolor);
    tgi_setpixel(x, y);
    usleep(DELAY);
  }
}

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include <c64.h>

//Demo screen parts:
void blot ();			//Draws an ink blot on the screen.
void colorblot ();		//Same, but colored.
void streamtop ();		//Fire curtain from top.
void main()
{
	unsigned char c;
	//clrscr();
	while (1) {
		bgcolor (1); bordercolor (4); //textcolor (5);
		puts	("\f\x90\x93\x12\x89 Screen Demo of Super Games Cart. Format\x92"
			"   by \x9aJoseph Rose\x99, a.k.a. \x96\x12Harry Potter\x99\n"
			"----------------------------------------\x90"
	
			"Choose your demo:\n\n"
			"1.  Ink Blot\n"
			"2.  \x1C""C\x81o\x9El\x1Eo\x1Fr\x90 Ink Blot\n"
			"3.  \x1C""Fire\x90 Curtain from Top"
			);
		c=cgetc()-'0';
		switch (c)
		{
		case 1: blot();		break;
		case 2: colorblot();	break;
		case 3: streamtop ();	break;
		}
	}
}

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "hide64.h"

char* __fastcall__ hstrncpy (char* dest, char* sour, unsigned len)
{
	char* d=dest;
	for (; len>0 && *sour!=0; --len)
	{
		hidewriteb (dest++, hidereadb(sour++));
	}
	hidewriteb (dest,0);
	return d;
}

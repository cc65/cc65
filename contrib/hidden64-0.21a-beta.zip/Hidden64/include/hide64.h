#ifndef __C64Hide_H
#define __C64Hide_H

// Read byte from behind ROM/IO.
unsigned char __fastcall__ hidereadb (const char* addr);
// Write byte to behind ROM/IO.
void __fastcall__ hidewriteb (char* addr, char val);

// Read word from behind ROM/IO.
unsigned __fastcall__ hidereadw (const unsigned* addr);
// Write word to behind ROM/IO.
void __fastcall__ hidewritew (unsigned* addr, unsigned val);

//Read data from an open file to hidden RAM.
int __fastcall__ h_cbm_read (unsigned char lfn, void* buffer, unsigned int size);

//Write data from hidden RAM to an open file.
int __fastcall__ h_cbm_write (unsigned char lfn, void* buffer, unsigned int size);

//Print a string stored behind ROM/IO.  Doesn't print CR.
void __fastcall__ printh (const char*);

//Like memmove and memcpy, except with the kernal/IO disabled.
void* __fastcall__ hmemmove (void* dest, const void* sour, size_t n);
void* __fastcall__ hmemcpy (void* dest, const void* sour, size_t n);

//Hidden versions of these functions:
void* __fastcall__ hmemset (void* ptr, int c, size_t n);
void* __fastcall__ _hbzero (void* ptr, size_t n);
void __fastcall__ hbzero (void* ptr, size_t n);
int __fastcall__ hstrlen (char* s);
void __fastcall__ hstrcpy (char* dest, char* sour);
void __fastcall__ hstrcat (char* dest, char* sour);
int __fastcall__ hmemcmp (const void* p1, const void* p2, size_t count);
int __fastcall__ hstrcmp (const void* p1, const void* p2);
char* __fastcall__ hstrncpy (char* dest, char* sour, unsigned len);
int __fastcall__ hstricmp (const void* p1, const void* p2);

//Load a memory image file on device 8 into memory starting at 0xD000.
//Assumes no starting address in file.
int hideloadfile (char* file);

//Memory allocation functions for hidden RAM:
void* hmalloc(size_t);
#endif

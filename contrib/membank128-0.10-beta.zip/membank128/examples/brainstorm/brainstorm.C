#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <ctype.h>
#include <conio.h>

#include <c128.h>

#include "membank128.h"

#include "dialog.h"
#include "env.h"
//void __fastcall__ pause ();

unsigned char file_error();

#pragma bss-name ("BASGRBSS")
char sentence [400];
char f[24];
static union {
	struct {
		unsigned noun;
		unsigned adj [3];
	} about;
	struct {
		unsigned subjadj [2];
		unsigned subj;
		unsigned verb;
		unsigned objadj [2];
		unsigned obj;
	} whodid;
} build;
//static unsigned buildtype;

int fastcall rand2 (int);

static unsigned char isvowel (char c)
{
	c=tolower(c);
	if (c=='a') return 1;
	if (c=='e') return 1;
	if (c=='i') return 1;
	if (c=='o') return 1;
	if (c=='u') return 1;
	return 0;
}
static void* verb_cvtsing (char* v)
{
	static char tmpv[24];
	static int l;
	l=strlen(v)-1;
	if (v[l]=='o' && !isvowel(v[l-1])) {
		strcpy (tmpv,v);
		strcat (tmpv, "es");
	} else if (v[l]=='s' || v[l]=='x' || v[l]=='z') {
		strcpy (tmpv,v);
		strcat (tmpv, "es");
	} else if (v[l]=='y' && !isvowel(v[l-1])) {
		strcpy (tmpv,v);
		tmpv[l]=0;
		strcat (tmpv, "ies");
	} else {
		strcpy (tmpv, v);
		strcat (tmpv, "s");
	}
	return tmpv;
	
}

#pragma bss-name ("TAPEBSS")

static unsigned findwordtype (unsigned t)
{
	//register unsigned i, j;
	//register unsigned numw;
	static unsigned i, j;
	static unsigned numw;
	switch (t) {
	case 0: numw=numparts.nouns; break;
	case 1: numw=numparts.verbs; break;
	case 2: numw=numparts.adj; break;
	case 3: numw=numparts.adv; break;
	}
	j=(rand()%numw)+1;
	for (i=0; i<numwords; ++i) {
		if (words[i].s==t) {
			j--; if (!j) return i;
		}
	} return -1;
}
void brainstorm1 ()
{
	static unsigned i;
	_randomize ();
	switch (rand()&1)
	{
	case 0: //About the <adj.> <noun>
		build.about.noun=findwordtype(0);
		memset (build.about.adj, -1, sizeof(build.about.adj));
		for (i=rand()%3; i>0; --i) {
			build.about.adj[i-1]=findwordtype(2);
		}
		//sentence[0]=0;
		strcpy(sentence, "The ");
		for (i=0; build.about.adj[i]!=-1; ++i) {
			if (i) strcat (sentence, ", ");
			strcat (sentence, words[build.about.adj[i]].word);
		} if (i) strcat (sentence, " ");
		strcat (sentence, words[build.about.noun].word);
		break;
	case 1:
		memset (&build.whodid, -1, sizeof(build.whodid));
		build.whodid.subj=findwordtype(0);
		build.whodid.verb=findwordtype(1);
		build.whodid.obj=findwordtype(0);
		strcpy(sentence, "The ");
		strcat (sentence, words[build.whodid.subj].word);
		strcat (sentence, " ");
		strcat (sentence, verb_cvtsing(words[build.whodid.verb].word));
		strcat (sentence, " to the ");
		strcat (sentence, words[build.whodid.obj].word);
		break;
	}
	strcat (sentence, ".");
}
static void brainstorm ()
{
	static char c;
	static char filename [17];
	clrscr ();
	puts	("\x9B\x12""Brainstorm 128\x92\x1E will now shuffle your words and attempt\n"
		 "to create a useful idea based on your input.\x9A");
	chline (80);
	puts	("Press any key to continue...");
	//pause();
	cgetc();
	do {
		brainstorm1(); 
		clrscr();
		textcolor (14);
		gotoy (5); puts (sentence);
		gotoy (8); puts ("\x90Is this a good idea (Y/N/X)?");
		c=cgetc();
		if (c=='x') return;
	} while (c!='y');
	puts ("Save it (Y/N)?");
	c=cgetc();
	if (c=='y') {
retry:
		puts ("Type in filename:");
		if (!GetInput (filename, 17)) return;
		strcpy (f,filename);
		strcat (f,",s");
		cbm_open (1,8,CBM_WRITE,f);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		cbm_write (1,&sentence, strlen(sentence)-1);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		cbm_close (1);
	}
}

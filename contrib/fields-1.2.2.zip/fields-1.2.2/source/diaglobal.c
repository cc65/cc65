#include <conio.h>
#include "dialog.h"

#if defined __C128__ || defined __APPLE2ENH__
unsigned char __Columns;
#endif

//Routine to draw the contents of a text field on the screen.
//Replaced by Greg King.
void __fastcall__ DrawField (unsigned char x, unsigned char y,
                                    unsigned char len, const char* s)
{
	//Clear field on screen.
	cclearxy (x,y,len);

	//Print field to screen in selected colors.
	cputsxy (x,y,s);
}

void reverson(void)
{revers(1);}
void reversoff(void)
{revers(0);}

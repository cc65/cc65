#ifndef	__Dialog_Field_H
#define	__Dialog_Field_H

#if !defined __APPLE2__ && !defined __APPLE2ENH__ && !defined __PET__ && !defined __CBM610__ && !defined __CBM510__
#define __COLOR__
#else
#define __MONO__
#endif

//-----------------------------------------------------------------

//Set screen columns for different computers:
#if defined __APPLE2__ || defined __C64__ || defined __PLUS4__ || defined __C16__ || defined __PET__ || defined __CBM510__
#define __Columns 40
#elif defined __CBM610__ || defined __C128__ || defined __APPLE2ENH__
//#define __Columns 80
extern unsigned char __Columns;
#endif
//Now rows:
#if defined __APPLE2__ || defined __APPLE2ENH__
#define __Rows 24
#else
#define __Rows 25
#endif

static void __fastcall__ delitemhelp (void);
void __fastcall__ DrawField (unsigned char x, unsigned char y,
                                    unsigned char len, const char* s);
#ifdef __COLOR__
/* Import colors for field-editing routines. */
extern char diaHilightCol, diaFieldCol, diaHelpCol;
void selcolor ();
void unselcolor();
#else
#define selcolor() revers(1)
#define unselcolor() revers(0)
#endif

signed char InTextField (field* f);
signed char InNumField (field* f);
signed char InSelField (field* f);
signed char InChkField (field* f);
void InTextWrite (field* f);
void InNumWrite (field* f);
void InSelWrite (field* f);
void InChkWrite (field* f);
#endif


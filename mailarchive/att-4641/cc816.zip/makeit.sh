#!/bin/bash
cl65 -c cc816.c
cl65 -c hash.c
cl65 -o cc816 cc816.o hash.o

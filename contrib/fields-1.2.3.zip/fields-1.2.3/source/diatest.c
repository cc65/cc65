#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <conio.h>

#ifdef __CBM__
#include <cbm.h>
#elif defined __APPLE2__ || defined __APPLE2ENH__
#include <apple2.h>
#elif defined __ATARI__
#include <atari.h>
#endif
#include "dialog.h"
#include "menus.h"

/* Colors */
//0,2,10,5,0,
#if defined __C64__ || defined __C128__
unsigned char diaLabelCol=0;
unsigned char diaNormalCol=2;
unsigned char diaHilightCol=10;
unsigned char diaTitleCol=5;
unsigned char diaHelpCol=0;
#elif defined __PLUS4__ || __C16__
unsigned char diaLabelCol=0;
unsigned char diaNormalCol=0x48;//2;
unsigned char diaHilightCol=0x6A;
unsigned char diaTitleCol=0x4F;
unsigned char diaHelpCol=0x2B;
#endif

/* Menus: */
struct menuitemops mnFile=
{
	6,6,
	"File",
	{"New", "Open", "Save", "Quit"}
};
struct menuitemops mnEdit=
{
	7,5,
	"Edit",
	{"Cut", "Copy", "Paste"}
};
struct menuitemops mnTest=
{
	15,4,
	"Tester",
	{"Op1", "Op2"}
};
/* Main menu: */
struct mainmenuops mnMain=
{
#ifdef __COLOR__
#if defined __C64__ || defined __C128__
	//2,5,
#else
	//0x62,0x25,
#endif
#endif
	9,6,
	{&mnFile, &mnEdit, &mnTest,&mnEdit,&mnFile,&mnTest}
};
#ifdef __COLOR__
#if defined __C64__ || defined __C128__
unsigned char menucolor=2, menuhicolor=5;
#else
	//0x62,0x25,
unsigned char menucolor=0x62, menuhicolor=0x25;
#endif
#endif

char *h="Help line";

field f;
char * CPUsel[]={
	"Amiga",
	"Apple",
	"Atari",
	"Commodore"
};
char* ComponentSel[]=
{
	"Graphics",
	"Sound",
	"Keyboard",
	"Mouse",
	"Joystick"
};
field fCPU={
	10,2,16,
	0,2,"Computer:",
	fldtSel,
	"Select a computer..."
};
field fComponent={
	10,3,16,
	0,3,
	"IC:",
	fldtSel
#ifndef __Fields_NoHelp__
	,"Select component."
#endif
};
field fRAM={
	10,4,17,
	0, 4, "RAM (k):",
	fldtNum
#ifndef __Fields_NoHelp__
	,"Type in RAM in k..."
#endif
};
field fUser={
	10, 5, 17,
	0, 5, "User:",
	fldtText
#ifndef __Fields_NoHelp__
	,"Type in your alias..."
#endif
};
field fLoggedIn={
	10,6,1,
	12, 6, "Logged in",
	fldtChk
#ifndef __Fields_NoHelp__
	,"Logged In?"
#endif
};
field fCost={
	10, 7, 12,
	0, 7, "CPU Cost",
	fldtMoney
#ifndef __Fields_NoHelp__
	,"Cost of the computer"
#endif
};
//field* flds[5]={&fCPU,&fComponent,&fRAM,&fUser,&fLoggedIn};

fldenv dia={
//#if  defined(__C64__) || defined(__C128__)
//	0,2,10,5,0,
//#elif defined(__PLUS4__) || defined(__C16__)
//	0x00,0x48,0x4A,0x45,0x41,
//#elif defined(__ATARI__)
//	_gtia_mkcolor(HUE_GREY,0),
//	_gtia_mkcolor(HUE_BLUE2,4),
//	_gtia_mkcolor(HUE_GREEN,6),
//	_gtia_mkcolor(HUE_GREY,0),
//	_gtia_mkcolor(HUE_ORANGE,4),
//#endif
	"Test Dialog",
#ifndef __Fields_NoHelp__
	"Just a demo...!",
#endif
	6,
	{&fCPU,&fComponent,&fRAM,&fUser,&fLoggedIn, &fCost}
};

struct _InF {
	unsigned char mach;
	unsigned char component;
	int RAM;
	char user[17];
	unsigned char loggedin;
	long cost;
} InF = {
	0,
	0,
	5,
	"Harry Potter",
	1,
	11995
};

int main ()
{
	unsigned r;
#if defined __C128__ || defined __APPLE2ENH__
/*	char c;
	puts   ("Press 4 for 40-column mode or 8 for 80-\n"
		"column mode now.");
	do c=cgetc(); while (c!='4' && c!='8');
		//while ((c=cgetc())!='4' && c!='8');
	videomode (c=='4'?VIDEOMODE_40COL:VIDEOMODE_80COL);
	__Columns=(c=='4'?40:80);*/
	videomode (VIDEOMODE_80COL);
#endif
#if  defined(__C64__) || defined(__C128__)
	bordercolor(3);
	bgcolor (1);
#elif defined(__PLUS4__) || defined(__C16__)
	bordercolor(0x6C);
	bgcolor (0x71);
#elif defined(__ATARI__)
	bordercolor(_gtia_mkcolor(HUE_GOLD, 4));
	bgcolor(_gtia_mkcolor(HUE_GREY,7));
#endif
	fCPU.data.sel.sel=&InF.mach;
	fCPU.data.sel.values=CPUsel;
	fCPU.data.sel.num=4;

	fComponent.data.sel.sel=&InF.component;
	fComponent.data.sel.values=ComponentSel;
	fComponent.data.sel.num=5;

	fRAM.data.num=&InF.RAM;

	fUser.data.text=InF.user;

	fLoggedIn.data.byte=&InF.loggedin;

	fCost.data.lnum=&InF.cost;

	r=dialog (&dia);

	clrscr ();
	printf ("Dialog returns: %d\n"
		"Computer:    %s\n"
		"Component:   %s\n"
		"RAM:         %dk\n"
		"User:        %s\n"
		"Logged in:   %s\n"
		"Cost:        %ld\n",
		//dia.field[0]->data.sel.values[InF.mach],
		//dia.field[1]->data.sel.values[InF.component],
		r,
		CPUsel[InF.mach],
		ComponentSel[InF.component],

		InF.RAM,
		InF.user,
		InF.loggedin?"true":"false",
		InF.cost);
	puts ("\n\nPress any key for menu demo.\n");
	cgetc();

	clrscr();
	r=mainmenu(&mnMain);
	//revers(0); clrscr();
	printf ("\f\x91Menu returned: %04.4X.\n\n", r);
	return 0;
}
/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c128.h>

#include "..\membank128.h"

int __fastcall__ bank1_strlen (char* s)
{
	static int len;
	for (len=0; bank1_readbyte(s+len); ++len);
	return len;
}

char* __fastcall__ bank1_strcpyin (char* dest, char* sour)
{
	bank1_memcpyin (dest, sour, bank1_strlen(sour));
	return dest;
}

char* __fastcall__ bank1_strcpyto (char* dest, char* sour)
{
	bank1_memcpyto (dest, sour, strlen(sour));
	return dest;
}

char* __fastcall__ bank1_strcpyfrom (char* dest, char* sour)
{
	bank1_memcpyfrom (dest, sour, bank1_strlen(sour));
	return dest;
}


#include <conio.h>
#include <stdio.h>

#ifdef __CC65__ 
#define CC65
#endif

#define WIDTH 25
#define HIGH 25
#define MAXR 46
//sqrt(WIDTH^2+HIGH^2)

static unsigned int sqrmedtab[46];

/* let q_n be the square of n and s_n=q_n+q_(n+1). 

the difference between s_n and s_(n+1) is 4*(n-1)+8.
let m be n-1.

we could compare S=x^2+y^2 with q_n, and if S>q_n
increase r. 

but this results in bad precision.

so i decided to compare S with s_n/2, which is
s_m+2*(m-1)+4.

let j_m=2*(m-1)+4, then j_(m+1)=j_m+2.
especially j_0 = 2.
*/

void calcsqrmed (void){
	unsigned int sqrsum=0;
	unsigned char i;
	unsigned char j;

	for(j=2,i=0;i<MAXR;j+=2,i++){
		sqrmedtab[i]=sqrsum;
		sqrsum+=j;
	}
}


void main(void){
	register unsigned int * betweensqr=sqrmedtab;
	unsigned int ysqr=0;
	unsigned int sqr=0;

	unsigned char x;
	unsigned char y;
	unsigned char r;

	calcsqrmed();

	clrscr();
	for(y=1;y<2*HIGH;y+=2){
		r=y>>1;
		gotoxy(0,r);
		for(x=1;x<2*WIDTH;x+=2){
#ifndef CC65
			if(betweensqr[r]<sqr){
				++r;
			}
#else		
			asm("ldy #%o",r);
			asm("lda (sp),y"); //get r
			asm("asl");
			asm("tay");
			asm("iny");	 //calc pointer into medsqrlist, r mustn't be greater than 127
			asm("lda (%v),y",betweensqr);
			asm("tax");
			asm("dey");
			asm("lda (%v),y",betweensqr);
			asm("jsr pushax"); // get [s_n+s_(n+1)]/2.
			asm("ldy #%o+2+1",sqr);
			asm("jsr ldaxysp");	// get sqr, which is x^2+y^2
			asm("jsr tosicmp");	 // compare with sqr
			asm("bcs dont_inc_r");
			
			asm("ldy #%o",r);
			asm("lda (sp),y");
			asm("adc #1");
			asm("sta (sp),y");

			asm("dont_inc_r:");
			/* above inline assembly equals following c expression:*/
#endif
			cputc('@'+r);

			sqr+=x;
		}
		sqr=ysqr+=y; //calc y^2 and copy to sqr
	}
	cgetc();
}

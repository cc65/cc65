#!/bin/sh
javac -source 1.3 -target 1.3 Lowerbit.java 

unsigned long int __fastcall__ something(void);

void main(void){
  unsigned long int anything;
  anything = something();
}

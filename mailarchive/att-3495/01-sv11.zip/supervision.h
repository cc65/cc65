/*****************************************************************************/
/*                                                                           */
/* 2003 Peter Trauner (trap@utanet.at)                                       */
/*                                                                           */
/*                                                                           */
/* This software is provided "as-is," without any expressed or implied       */
/* warranty.  In no event will the authors be held liable for any damages    */
/* arising from the use of this software.				     */
/*									     */
/* Permission is granted to anyone to use this software for any purpose,     */
/* including commercial applications, and to alter and redistribute it	     */
/* freely, subject to the following restrictions:			     */
/*									     */
/* 1. The origin of this software must not be misrepresented; you must not   */
/*    claim that you wrote the original software.  If you use this software  */
/*    in a product, an acknowledgment, in the product's documentation,	     */
/*    would be appreciated, but is not required.			     */
/* 2. Alterred source versions must be marked plainly as such,		     */
/*    and must not be misrepresented as being the original software.	     */
/* 3. This notice may not be removed or alterred		 	     */
/*    from any source distribution.					     */
/*****************************************************************************/

#ifndef _SUPERVISION_H
#define _SUPERVISION_H

#include <stdint.h>
#include <stdbool.h>

typedef struct {
  uint8_t width, height, xpos, ypos;
} t_sv_lcd;
#define SV_LCD ((t_sv_lcd*)0x2000)

typedef struct {
  uint16_t delay;
  uint8_t control, timer;
} t_sv_tone;
#define SV_RIGHT ((t_sv_tone*)0x2010)
#define SV_LEFT ((t_sv_tone*)0x2014)

typedef struct {
  uint8_t volume, // and frequency
    timer, control;
} t_sv_noise;
#define SV_NOISE ((t_sv_noise*)0x2028)

typedef struct {
  uint8_t in,out;
} t_io_port;
#define IO_PORT ((t_io_port*)(0x2021)

typedef struct {
  uint16_t start;
  uint8_t size, control, on;
} t_sv_dma;
#define SV_DMA ((sv_dma*)0x2018)

#define SV_CONTROL (*(uint8_t*)0x2020)

#define SV_BANK (*(uint8_t*)0x2026)
#define SV_BANK_COMBINE(nmi,irq_timer,irq_dma,lcd_on, timer_prescale, bank) \
	(nmi?1:0)|(irq_timer?2:0)|(irq_dma?4:0)|(lcd_on?8:0) \
	|(timer_prescale?0x10:0)|(bank<<5)

#define SV_VIDEO ((uint8_t*)0x4000)
#define SV_TIMER_COUNT *((uint8_t*)0x2023)

// asynchronous! incremented
extern uint8_t sv_nmi_counter;
extern uint8_t sv_timer_irq_counter;
extern uint8_t sv_timer_dma_counter;
// if you want more complex, copy the crt0.s file from the libsrc/supervision directory
// and code them yourself (in assembler)

#endif

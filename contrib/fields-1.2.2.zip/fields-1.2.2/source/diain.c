#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <ctype.h>
#include <conio.h>

#ifdef __CBM__
#include <cbm.h>
#endif
#ifdef __APPLE2__
#include <apple2.h>
#endif
#ifdef __APPLE2ENH__
#include <apple2enh.h>
#endif
#ifdef __ATARI__
#include <atari.h>
#define CH_ENTER CH_EOL
#endif

#include "dialog.h"

void HelpCol (void);

//static and __fastcall__ declarations recommended by Greg King.
/* Import colors for field-editing routines. */
extern char diaHilightCol, diaHilightCol;
#ifndef __Fields_NoHelp__
extern char diaHelpCol;
#endif
//Define color macros:
//selcolor() = Color(s) for selected text.
//unselcolor() = Color(s) for normal text.

//For computers with colors:
#ifdef __COLOR__
void selcolor (void)
{
	textcolor (diaHilightCol);
	//revers(1);
	reverson();
}
void unselcolor(void)
{
	//revers(0);
	reversoff ();
	textcolor(diaNormalCol);
}
//For computers with no colors:
#else
void selcolor(){
	//revers(1);
	reverson();
}
void unselcolor()
{
	revers(0);
	//revers0ff();
}
#endif
//-----------------------------------------------------------------

//Set screen columns for different computers:
#if defined __APPLE2__ || defined __C64__ || defined __PLUS4__ || defined __C16__ || defined __PET__ || defined __CBM510__ || defined __ATARI__
#define __Columns 40
#elif defined __CBM610__
#define __Columns 80
#elif defined __APPLE2ENH__ || defined __C128__
extern unsigned char __Columns;
#endif
//Now rows:
#if defined __APPLE2__ || defined __APPLE2ENH__ || defined __ATARI__
#define __Rows 24
#else
#define __Rows 25
#endif

#ifndef __Fields_NoHelp__
static void __fastcall__ placehelp (char* s)
{
#ifdef __COLOR__
	//textcolor (diaHelpCol);
	HelpCol();
#endif
	DrawField (0,__Rows-3,__Columns,s);
}
#endif
// Following routine has been discontinued by recommendation of Greg King.
/*void EmptyField (unsigned x, unsigned y, unsigned len)
{
	gotoxy (x,y);
	for (;len>0;--len) cputc (32);
}*/

#ifndef __Fields_NoMoney__
void __fastcall__ printmoneyhere (field* f)
{
	static char m[15]="$%2.2ld.%02.2ld";
	long n=*f->data.lnum;
	m[2]=m[4]=(f->len-4)+'0';
	gotoxy (f->x,f->y);
	//cprintf (m, n/100, (n/10)%10, n%10);
	cprintf (m, n/100, n%100);
}

static int __fastcall__ InMoneyField (field* f)
{
	char c; char r=0;
	long *x=f->data.lnum;
	//long m=*x;//f->data.lnum;
#ifndef __Fields_NoHelp__
	placehelp ("Type in price, as in a calculator");
#endif
	selcolor();
	
	do {
		//*x/**f->data.lnum*/=m; 
		printmoneyhere(f);
		c=cgetc();
		if (isdigit(c))		//m=m*10+(c-'0');
			*x=*x*10+(c-'0');
		switch (c){
		case CH_DEL://m/=10; break;
			*x/=10; break;
#ifdef CH_EOL
			case CH_EOL:
#else
			case CH_ENTER:
#endif
				++r;
#ifdef CH_STOP
			case CH_STOP:
#endif
			case CH_ESC:
				++r;
		case CH_CURS_DOWN: 	++r;
		case CH_CURS_UP: 	++r; break;
		}
	} //while (!r);
	while (r==0);
	unselcolor ();
	//*f->data.lnum=m;
	printmoneyhere(f);
	return r-1;
}
#endif

#ifndef __Fields_NoChk__
static int __fastcall__ InChkField (field* f)
{
	unsigned char i=*f->data.byte;
	unsigned char r=0;
	//char c;
	unsigned char x=f->x, y=f->y;
#ifndef __Fields_NoHelp__
	placehelp ("Up/down:move Space:toggle Enter: cont.");
#endif
	selcolor();

	do
	//while (!r)
	{
		cputcxy (x, y, i?'X':' ');
		/* Process. */
		switch (cgetc())//(c)
		{
		/* Exit good if enter key pressed. */
		case ' ': i=!i; break;
//		case CH_ENTER: ++r;
//		case CH_CURS_DOWN:
//			++r; //break;
//		case CH_CURS_UP:
//			++r; break;
#ifdef CH_EOL
		case CH_EOL:
#else
		case CH_ENTER:
#endif
			++r;
#ifdef CH_STOP
		case CH_STOP:
#endif
		case CH_ESC:
			++r;
		case CH_CURS_DOWN: ++r;
		case CH_CURS_UP:   ++r; break;
		}
	} while (!r);
	unselcolor();
	*f->data.byte=i;
	cputcxy (x, y,i?'X':' ');
	//WriteInChkField (f);
	return r-1;
}
#endif


#ifndef __Fields_NoSel__
/*void __fastcall__ WriteInSelField (field* f)
{
	DrawField (f->x, f->y, f->len, f->data.sel.values[*f->data.sel.sel]);
}*/

//Signed char return type recommended by greg King.
static signed char __fastcall__ InSelField (field* f)
{
	// r's initialization was moved
				/* Temp. values. */
	unsigned char r=0;
	//flddatasel* d=&f->data.sel;
	unsigned char sx=*f->data.sel.sel;/* Quick access to # user
					 * selection. */
	char** s=f->data.sel.values;	/* Quick access to selection
					 * values */
	unsigned char x=f->x, y=f->y;
	unsigned char len=f->len-1;
	unsigned char n=f->data.sel.num;
#ifndef __Fields_NoHelp__
#if defined __C128__ || defined __APPLE2ENH__
	placehelp (__Columns>40?
		"Left/right:select Up/down:move Enter: continue":
		"Left/right:select Up/down:move Enter");
#elif __Columns==40
	/* Print field type help for 40-column screen. */
	placehelp ("Left/right:select Up/down:move Enter");
#else
	/* Print field type help for 80-column screen. */
	placehelp ("Left/right:select Up/down:move Enter: continue");
#endif
#endif
	/* Set to selection color. */
	selcolor();
	/* Main routine loop. */
	do
	{
		/* Write current user selection. */
		DrawField (x, y, len, s[sx]);
		/* Get key. */
		// switch modified from orig. by Greg King:
		// * if(incntrl(c) removed.
		// * First four conditions replaced.
		switch (cgetc())//(c)
		{
		/* If cursor left: */
		case CH_CURS_LEFT:
			//decrease field # w/ wrap.
			if (--sx==0xFF) sx=n-1;
			break;
		/* If right: */
		case CH_CURS_RIGHT:
			/* Increase selection #. */
			++sx;
			//if (++sx>=n) sx=0;
			if (sx>=n) sx=0;
			//sx=(sx+1)%n;
			break;
		///* If up/down, move to prev. or next field. */
#ifdef CH_EOL
		case CH_EOL:
#else
		case CH_ENTER:
#endif
			++r;
#ifdef CH_STOP
		case CH_STOP:
#endif
		case CH_ESC:
			++r;
		case CH_CURS_DOWN: ++r;
		case CH_CURS_UP:   ++r; break;
		}
	} while (!r);
	/* Draw field in unselected colors. */
	unselcolor();
	DrawField (x, y, len, s[sx]);
	/* Write selection #. */
	*f->data.sel.sel=sx;
	//*d->sel=sx;
	//WriteInSelField (f);
	/* Exit with return code. */
	return r-1;
}
#endif


signed char __fastcall__ InField (field* f)
{
	// Temporary field data
	char in[81];
	unsigned char c;	// Tmp. char
	//unsigned i;		// Tmp. var
	unsigned char r=0;	// Return value.
	unsigned char sx=0;	// Tmp. x pos. in field
	unsigned char tmplen=f->len-1;
	unsigned char x=f->x, y=f->y;
	unsigned char t=f->type;


	//Display help.
#ifndef __Fields_NoHelp__
#ifdef __COLOR__
	//textcolor (diaHelpCol);
	HelpCol ();
#endif
	DrawField (0, __Rows-2,__Columns-1, f->help);
#endif
	//Copy field to temp. field.
	switch (t)
	{
#ifndef __Fields_NoSel__
	case fldtSel:	return InSelField (f);
#endif
#ifndef __Fields_NoChk__
	case fldtChk:	return InChkField (f);
#endif
#ifndef __Fields_NoMoney__
	case fldtMoney:	return InMoneyField (f);
#endif
	case fldtText:	strcpy (in,f->data.text);	break;
	case fldtNum:	itoa (*f->data.num, in,10);	break;
	}
#ifndef __Fields_NoHelp__
	placehelp (t==fldtText?
		"Type text. Up/down:move, Enter:continue":
		"Type #. Up/down:move, Enter:continue");
#endif
	// Write field to screen.
#if !defined __APPLE2ENH__ && !defined __APPLE2__
	selcolor();
#endif
	//Main loop for keyboard input.
	do//while (r==-1)
	{
		//Get key with cursor.
		//DrawField (x, y, tmplen/*f->len*/, in);
		//gotox (x+sx);
#if defined __APPLE2ENH__ || defined __APPLE2__
		selcolor();//revers (1); 
		DrawField (x, y, tmplen/*f->len*/, in);
		gotox (x+sx);
		unselcolor();//revers (0);
		if (sx<tmplen) cputc (127);//revers (0); cputc (127); revers (1); 
		c=cgetc();
#elif defined __ATARI__
		c=cgetc();
#else
		DrawField (x, y, tmplen/*f->len*/, in);
		gotox (x+sx);
 		cursor(1);
		c=cgetc();
		cursor(0);
#endif
		if (c==CH_DEL/*|| c==127*/) {
			//if (sx>0) {
			if (sx) {
				//in[strlen(in)]=0;
				--sx;
				/* move the rest of the field left to cover current pos., */
				memmove (&in[sx], &in[sx+1],81-sx);//strlen(&in[sx]));
				/* and move the cursor left. */
			} continue; //break;
			/* If cursor left */
		}
		//If the key is a displayable character
		//(# if field is a number or text if text)
		else if (((isdigit(c)||(c=='-'&&!sx))&&t==fldtNum)
			|| (isprint(c)&&t==fldtText)) {
			//ignore if end of field.
			if (strlen(in)>=tmplen/*f->len*/) continue;
			memmove (&in[sx+1], &in[sx],tmplen-sx);
			if (in[sx]==0) in[sx+1]=0;
			in[sx++]=c; //if (sx>=strlen(in))

			//Print char and advance x.
		//If control character, do:
		} else /*if (iscntrl(c))*/ {
			//r=-1; /* Set return value to -1 for no exit. */
			switch (c)
			{
			/* Exit loop if enter. */
			//case CH_ENTER: r=2; break;
#ifdef CH_INS	/* Recommended by Greg King. */
			/* If insert key: */
			case CH_INS:
				/* If field not full, */
				if (strlen(in)<tmplen/*f->len*/) {
					/* open space for new character, */
					memmove (&in[sx+1], &in[sx],81-sx);//strlen(&in[sx]));
					/* write space to current pos. */
					in[sx]=32;
				} break;
#endif
			/* If delete */
//#if defined __APPLE2__ || defined __APPLE2ENH__
//			case 127:
//#else
//			case CH_DEL:
//#endif
//				/* and cursor not at left of field, */
//				if (sx>0) {
//					//in[strlen(in)]=0;
//					--sx;
//					/* move the rest of the field left to cover current pos., */
//					memmove (&in[sx], &in[sx+1],81-sx);//strlen(&in[sx]));
//					/* and move the cursor left. */
//				} break;
			/* If cursor left */
			case CH_CURS_LEFT:
				/* and not at left of the screen, move cursor left. */
				if (sx>0) --sx; break;
			/* If cursor right */
			case CH_CURS_RIGHT:
				/* and not at end of field, move cursor right. */
				if (in[sx]) ++sx; break;
			/* If up/down, mark return value for move up/down. */
			//case CH_CURS_UP:
			//	r=0; break;
			//case CH_CURS_DOWN:
			//	r=1; break;
#ifdef CH_EOL
			case CH_EOL:
#else
			case CH_ENTER:
#endif
				++r;
#ifdef CH_STOP
			case CH_STOP:
#endif
			case CH_ESC:
				++r;
			case CH_CURS_DOWN: ++r;
			case CH_CURS_UP: ++r; break;
			}
			/* Exit loop if return code set for exit. */
			//if (r!=-1) break;
		}
	} while (!r);
	/* Draw field unhilighted. */
#if !defined __APPLE2ENH__ && !defined __APPLE2__
	unselcolor();
#endif
	DrawField (x, y, tmplen/*f->len*/, in);

	/* Save field information to the field descriptor. */
	switch (t)
	{
	/* If text, */
	case fldtText:
		/* Copy field to memory. */
		strcpy(f->data.text, in);
		break;
	/* If #: */
	case fldtNum:
		/* convert to int and save. */
		*f->data.num=atoi (in);
		break;
	}
	return r-1;
}

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>


#include "menu.h"

void main ()
{
	/* Set screen colors. */
#if defined __C16__ || defined __PLUS4__
	bgcolor (COLOR_WHITE);
	bordercolor(0x65);
	textcolor (0x42);
#elif defined __C64__ || defined __VIC20__
	bgcolor(COLOR_WHITE); bordercolor(COLOR_LIGHTGREEN); textcolor(COLOR_PURPLE);
#elif defined __C128__
	bgcolor(COLOR_WHITE); bordercolor(COLOR_LIGHTGREEN); textcolor(COLOR_VIOLET);
#endif
	/* Get selected program name. */
	SelPrg();
	/* If cancel, abort. */
	if (prg[0]==0) {
		clrscr();
		puts ("Program aborted!");
		return;
	}
	/* Clear screen and write load/run commands to screen. */
	clrscr();
	printf ("\x93\n\nload\"%s\",8,1\n\n\n\n\n"
		"run\x13",
		prg);
	gotoxy(0,0);
	/* Write two Returns to the keyboard buffer. */
#ifdef __C64__
	*((char*)0xC6)=2;	//# keys to write to buffer.
	*((char*)0x277)=13;	//Write two Returns.
	*((char*)0x278)=13;
#elif defined __C16__ || defined __PLUS4__
	*((char*)0xEF)=2;	//# keys to write to buffer.
	*((char*)0x527)=13;	//Write two Returns.
	*((char*)0x528)=13;
#elif defined __C128__
	*((char*)0xD0)=2;//CC
	*((char*)0x34A)=13;	//Write two Returns.
	*((char*)0x34B)=13;	
#endif
	/* Exit. */
}


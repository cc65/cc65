
#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <conio.h>
#include <cc65.h>
#include <tgi.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <stdint.h>
#include <limits.h>
#include <cbm.h>


char** argv2;

/* Resolution */
static unsigned int XRes, YRes;

#define PARAMS P(x_start, X_START) P(y_start,Y_START) P(r_start,R_START) P(r_min,R_MIN) 
// Dummy for substitution of either first or second argument with succeding comma.
// This way the params can be used within an enum or within a string array

enum paramlist
{
  #define P(x,y) y,
  PARAMS
  PARAMCOUNT
  #undef P
};
//Use above param list to define enums with each second argument of the list, separated by comma

static const unsigned char* paramnames[] = 
{
  #define P(x,y) #x,
  PARAMS 
  " " 
  #undef P
};
//Use above param list with stringification to define string array with each first argument of the list, separated by comma

static int paramarray[PARAMCOUNT];
//Define array to hold parameter values. The size of the array grows or diminishes with the number of params

static int paramlowbounds[PARAMCOUNT] = {-32768, -32768, 4, 2};/*Although cc65 issues a warning, -32768=0x8000 fits in integer!*/
static int paramupbounds[PARAMCOUNT] = {32767, 32767, 256, 256};//Predefined values for 320x200 resolution

static unsigned int scale;

static void Error (const char* Format, ...)
{
    va_list ap;

    /* Print an error and exit */
    va_start (ap, Format);
    vfprintf (stderr, Format, ap);
    va_end (ap);
    fputc ('\n', stderr);
    exit (EXIT_FAILURE);
}

static void CheckTGIError (const char* S)
{
    unsigned char ErrCode = tgi_geterror ();

    if (ErrCode != TGI_ERR_OK) {
        //tgi_unload ();
				/*tgi_unload () is registered in atexit() function!*/

        Error ("%s: %d", S, Error);
    }
}

void __fastcall__ circfrac(unsigned int x, unsigned int y, unsigned int size)
/* The recursive routine for the circle fractal*/
{
    unsigned int size2;
    
		if(kbhit())
		{
			if (CH_STOP == cgetc())
			{
				Error("Drawing of figures interrupted by user.");
			}
		}

    tgi_ellipse(x-1,y-1,(size2=size*256ul/scale)-1/*If initial radius is 256, then we need unsigned long to hold nominator.*/
                ,size-1); /*Can only draw ellipses with radii smaller than 256!
                By subtracting one and taking account of the given ranges for the command line args, the radii are always smaller than 256*/
    if ( (size/=2) >= paramarray[R_MIN] )
    {
      size2/=2;
      circfrac(x-size2,y,size);
      circfrac(x,y-size,size);
      circfrac(x+size2,y,size);
      circfrac(x,y+size,size);
    }
}

void forallparams(void (*func) (uint8_t j) )
/*Outer loop for all functions which have to be executed for each command line argument*/
{
  uint8_t i;
  
  for (i=0;i<PARAMCOUNT;i++)
  {
    func(i);
  }
}

void PrintParamNamesAndBounds(uint8_t j)
/*Prints out the parameters which have to be specified by the command line and their corresponding ranges. To be used with forallparams().*/
{
  printf("%s [%d..%d]", paramnames[j], paramlowbounds[j], paramupbounds[j]);
  if(j<PARAMCOUNT-1)
  {
    printf(",\n");
  }
}

void CheckParamRange(uint8_t j)
/* Checks, if given command line args are in the ranges given by paramlowbounds[] and paramupbounds[]*/
{	long int paramvalue;
	paramvalue = strtol(argv2[j+1], NULL, 0);

  if (ERANGE == errno)
  {
    Error("Value far off range in %s = %ld",paramnames[j],paramvalue);
  }
  if (paramlowbounds[j]>paramvalue)
  {
    Error("Low bound exceeded in %s = %ld",paramnames[j],paramvalue);
  }
  
  if (paramupbounds[j]<paramvalue)
  {
    Error("Upper bound exceeded in %s = %ld",paramnames[j],paramvalue);
  }
  
  paramarray[j] = paramvalue;
}

void ShowInterpretedParamValues(uint8_t i)
/* Prints out the results of the ascii to integer convertion of the command line arguments. To be used with forallparams().*/
{
  printf("%s = %d\n", paramnames[i], paramarray[i]);
}

void PrintParamPlaceholder(uint8_t i)
{
  printf(i<PARAMCOUNT-1?"#, ":"#\n");
}

void InitGraphics(void){
  /* Load and initialize the driver */
    /* Unload the driver */
    atexit(tgi_unload);
    printf ("Loading driver, please wait ...\n");
    tgi_load_driver (tgi_stddrv);
    CheckTGIError ("tgi_load_driver");
    
    scale = (tgi_getaspectratio()+64)&0xff80;//Round aspect to avoid too many bad set pixels
    printf("Pixel Aspect: %x\n",scale);
    /* Switch to graphics mode */
    
    tgi_clear ();

    CheckTGIError ("tgi_init");

    /* Remember the resolution */
    XRes = tgi_getxres ();
    YRes = tgi_getyres ();
}

void CheckR_MIN(void){
	unsigned int r;

  r = paramarray[R_START];
	while( (r&1) == 0 ){
    r/=2;
  }
  if (paramarray[R_MIN] < r)
  {
    printf("Warning: Each smaller circle has half the radius of the next bigger circles. The radius of the smallest circles can't be reached without precision loss by successive division by 2\n");
  }
}

int main (int argc, char* argv[])
{
    argv2=argv;

    printf ("\n*** Fractal with circles displaced along x/y axes ***\n"
            "Compiled with cc65 Version %d.%d.%d.%d\n\n",
            __CC65__ >> 12, (__CC65__ >> 8) & 15,
            (__CC65__ >> 4) & 15, __CC65__ & 15);
    
       
    if (argc!=PARAMCOUNT+1)
    {
      printf("Usage-> RUN:REM ");
      forallparams(PrintParamPlaceholder);
      printf("where each # is to be replaced by:\n");
      forallparams(PrintParamNamesAndBounds);
      
      Error("\n\nUse STOP key to interrupt recursion and exit.");
    }/*This section of code prints information about how to use the program*/
    
    forallparams(CheckParamRange);

    /* Checks for validity of command line args. Because argv[] is needed, forallparams(index) cannot be used*/
    

  
    /*Print out the command line args again, to show the interpreted values and let the user compare them to the input*/
    printf( "Parameters read (inclusive filename):%d\n", argc);
    forallparams(ShowInterpretedParamValues);
    
    putchar('\n');
    
    CheckR_MIN();

    InitGraphics();

    printf ("Press key\n");
    cgetc ();
    tgi_init ();
                
    /* Start recursion with initial coordinates, 
       initial sidelength and initial height */	
    circfrac (paramarray[X_START], paramarray[Y_START], paramarray[R_START]);
    
    cgetc();
    
    /* Done */
    printf ("Done\n");
    return EXIT_SUCCESS;
}

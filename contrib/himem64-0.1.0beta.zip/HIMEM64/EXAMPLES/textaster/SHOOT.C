/**************************************************************************
 *
 * Individual C module created by TempC Small for DOS.
 *
 * The end-user may use this code as he/she likes under the following
 * conditions:
 *
 * 1. TempC, along with its author, is mentioned in the program's 
 *    documentation, and
 * 2. If this source code is published, this header must be kept
 *    intact.
 *
 **************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <c64.h>
#include <conio.h>

static unsigned char joy;
static struct {
	struct {
		unsigned char x,y;
	} co[10];
	unsigned char level, num, speed;
} board;
static struct {
	unsigned char x,y;
	struct {unsigned char x,y;} fire[10];
	unsigned char numfires;
	unsigned char lives, enemkilled;
	unsigned char kill;
} player;
static void setup()
{
	unsigned char i;
	_randomize ();
	bzero (&board, sizeof(board));
	board.level=board.num=1;
	player.lives=3;
	for (i=0; i<10; ++i) {board.co[i].x=rand()%38+1; board.co[i].y=1;}
	(*(unsigned char*)0xA2)=0;
}
static void dispstatus ()
{
	gotoxy (0,0);
	textcolor (13); revers(1);
	cprintf ("score: %4.4d0 level: %2.2d lives: %2.2d        ",
		(unsigned) player.enemkilled, (unsigned) board.level, (unsigned) player.lives);
	revers(0);
}
static void moveplayer ()
{
	unsigned char i; 
	unsigned j;
	joy=(*(unsigned char*) 0xDC00);
	cclearxy (player.x, 21, 3);
	if (joy&0x08 && player.x>0) --player.x;
	if (joy&0x04 && player.x<37) ++player.x;
	textcolor (7);
	cputsxy (player.x, 21, "\xAB\xB1\xB3");
	if (!(joy&0x10)) {
		while ((*(unsigned char*) 0xA2)%5<3) {
			textcolor (1);
			cvlinexy (player.x+1,1,17);
			for (j=0; j<2048; ++j);
			textcolor (0);
			cvlinexy (player.x+1,1,17);
			for (j=0; j<2048; ++j);
		} for (i=0; i<board.num; ++i) {
			if (player.x+1==board.co[i].x) {
				board.co[i].x=rand()%38+1; board.co[i].y=1;
				++player.enemkilled;
			}
		}
	} dispstatus ();
}

static void moveboard ()
{
	unsigned char i;
	unsigned j;
	moveplayer();
	textcolor (8);
	for (i=0; i<board.num; ++i) cputcxy (board.co[i].x, board.co[i].y, ' ');
	for (i=0; i<board.num; ++i) {++board.co[i].y; if (board.co[i].y>=20) player.kill=1;}
	for (i=0; i<board.num; ++i) cputcxy (board.co[i].x, board.co[i].y, '*');
}

static void drawboard()
{
	unsigned char i,j;
	bgcolor (0); bordercolor (10); clrscr();
	gotoy (20); textcolor (1); chline (40);
	//gotoxy (0,0); printf 
	setup();
	dispstatus();
	//moveplayer();
}

void runboard ()
{
	//setup();
	drawboard();
	//cgetc();
	while (!player.kill)
	{
		while ((*(unsigned char*) 0xA2)<5);
		moveplayer();
		while ((*(unsigned char*) 0xA2)<10);
		(*(unsigned char*) 0xA2)=0;
		moveboard();
	}
}

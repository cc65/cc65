/*
 * Marc 'BlackJack' Rintsch, 06.03.2001
 *
 * unsigned int cbm_load(const char* name,
 *                       unsigned char device,
 *                       const unsigned char* data);
 */
#include <stdio.h>
#include <cbm.h>
#include "..\membank128.h"

/* loads file "name" from given device to given address or to the load address
 * of the file if "data" is 0
 */
unsigned int bank1_cbm_load(const char* name, unsigned char device, void* data)
{
	/* LFN is set to 0 but it's not needed for loading.
	 * (BASIC V2 sets it to the value of the SA for LOAD) */
	static int i;
//putchar ('1');
	cbm_k_setnam(name);
	cbm_k_setbnk (0, 0);
	cbm_k_setlfs(0, device, data == 0);
//putchar ('2');

	i=(cbm_k_load(0, (unsigned int)data) - (unsigned int)data);
printf ("ST: %d\n", cbm_k_readst());
	//return (cbm_k_load(0, (unsigned int)data));
	//i=(cbm_k_load(0, (unsigned int)data));
	//cbm_k_setbnk (0, 0);
//putchar ('3');
//putchar (13);
	return i;
}

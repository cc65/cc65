#ifndef __Dialog_H
#define __Dialog_H

#if !defined __APPLE2__ && !defined __APPLE2ENH__ && !defined __PET__ && !defined __CBM610__ && !defined __CBM510__
#define __COLOR__
#else
#define __MONO__
#endif

#ifdef __COLOR__
extern unsigned char
		diaLabelCol,
		diaNormalCol,
		diaHilightCol,
		diaTitleCol
#ifndef __Fields_NoHelp__
		,diaHelpCol
#endif
;
#endif

/* Selector field data type */
typedef struct _flddata_sel
{
	unsigned char* sel;		/* # current selection from user, value at
					 * given address */
	unsigned char num;		/* # possible selections */
	char** values;			/* pointers to selector text */
} flddatasel;

typedef struct _flddata_seli
{
	unsigned char* sel;		/* # current selection from user, value at
					 * given address */
	unsigned char num;		/* # possible selections */
	int* values;			/* pointers to selector text */
} flddataseli;

/* User-entered data types */
typedef union _flddata
{
	char* text;			/* Text entered by user, buffer must be
					 * large enough to hold text. */
	int* num;			/* Number, entered by user. */
	unsigned char* byte;		/* Check box bool */
	long *lnum;			/* ##.## if money */
	flddatasel sel;			/* Selector field, as specified
					 * above. */
} flddata;

typedef struct _field
{
	unsigned char x,y, len;		/* location and len. of field. */
	unsigned char lx, ly;		/* location of label */
	char* label;			/* label of field */
	/* Type of field: */
	enum {fldtNum,			/* Integer, */
		fldtText,		/* Text, */
		fldtSel,		/* Selection, */
		fldtChk,		/* Check box, */
		fldtMoney,		/* Money, */
		fldtSpin		/* Select # (Spin control) */
		} type;
#ifndef __Fields_NoHelp__
	char* help;			/* Field help */
#endif
	flddata data;			/* Data in field */
} field;

typedef struct _fldenv
{
//Exclude colors from monochrome computers
#if !defined __APPLE2__ && !defined __APPLE2ENH__ && !defined __PET__ && !defined __CBM610__ && !defined __CBM510__
//	unsigned char lblcolor;		// text color of label
//	unsigned char color;		// text color of field
//	unsigned char actcolor;		// text color of field when selected
//	unsigned char titlecol;		// text color for title
//	unsigned char helpcol;		// text color for help
#define __COLOR__
#else
#define __MONO__
#endif
	char* title;			// title of dialog
#ifndef __Fields_NoHelp__
	char* globalhelp;		// help for dialog
#endif
	unsigned numfields;		// # fields in dialog
	field* field[];			// pointers to fields
} fldenv;

#if defined(__C128__) || defined(__APPLE2ENH__)
extern unsigned char __Columns;
#else
#define __Columns 40
#endif
void __fastcall__ DrawField (unsigned char x, unsigned char y,
	unsigned char len, const char* s);

// The next two functions' declaration and return type were altered by Greg King. */
//Process text or number field.
//Returns 0 for prev. field, 1 for next,
//2 for advance to next step (i.e. process a dialog or go to
//   next step dialog),
//3 for cancel.
unsigned char __fastcall__ InField (field* f);

// Highlight and unhilight text:
void selcolor(void);
void unselcolor(void);
void reversoff(void);
void reverson(void);
/* Displays a dialog box-like screen, fields specified by f.
 * Returns 0 if good or 1 if cancelled. */
unsigned char __fastcall__ dialog (fldenv* f);

/* Prints the text of a money field as specified in f. */
void __fastcall__ printmoneyhere (field* f);

#endif
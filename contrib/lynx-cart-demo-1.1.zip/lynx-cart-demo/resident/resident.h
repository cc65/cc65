#define START_IRQS   1
#define RESTART_LYNX 2
#define SKETCH    8
#define NEXT_APPLICATION    100
#define PREV_APPLICATION    101
#define INTRO_FILENR        2
#define SKETCH_FILENR       3

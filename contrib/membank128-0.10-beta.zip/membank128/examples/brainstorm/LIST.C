#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include <c128.h>
#include "membank128.h"
#include <conio.h>
#include "env.h"

#pragma bss-name ("TAPEBSS")
#pragma code-name ("APPCODE")
void ListWords ()
{
	static int i, j;
	static unsigned char page;
	page=0;
	//clrscr(); gotox (30); puts ("\x96\x12""BrainStorm 128\x92\x90");
	//gotox (32); puts("\x1EList of Words\x90");
	//gotox (18); puts ("by \x99Joseph Rose\x90, a.k.a. \x9AHarry Potter\x90");
	//chline (78); putchar (13);
	WriteHeader ("List of Words");
	//textcolor (0);	
	for (i=0; i<numwords; ++i) {
		for (j=i-1; j>=0; --j) {
			if (!stricmp (words[i].word, words[j].word)) continue;
		}
		printf ("%-39.39s ", words[i].word); ++page;
		if (page>=40){
			textcolor (5);
			cputsxy (0,24,"Press any key for more...");
			cgetc();
			WriteHeader ("List of Words");
			//textcolor (0);
			gotoy (5); page=0;
		}
	}
	textcolor (5);
	cputsxy (0,24,"Press any key to exit...");
	cgetc();
}
#pragma rodata-name ("APPCONST")

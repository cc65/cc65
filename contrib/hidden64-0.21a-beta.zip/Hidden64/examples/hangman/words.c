/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c64.h>
#include "hide64.h"

#include "words.h"

//Total # distinct boards and categories in database.
const unsigned char numboards=25;
const unsigned char numcate=5;

//All text in this file is in hidden RAM.
#pragma rodataseg ("HIDECONST")
#pragma dataseg ("HIDEDATA")

//Category names:
char * catetext[]=
{
	"Phrase",
	"Fun and Games",
	"Movies & TV",
	"Science",
	"Food & Drink"
};
//Boards:
struct boards boards []=
{
	//Puzzles 0-4:
	{"super mario bros",		1,cGame},
	{"legend of zelda",		1,cGame},
	{"sonic the hedgehog",		1,cGame},
	{"pac-man",			1,cGame},
	{"star trek",			1,cTV},
	//Puzzles 5-9:
	{"sesame street",		1,cTV},
	{"mcdonalds",			1,cFood},
	{"chinese food",		1,cFood},
	{"biology",			1,cScience},
	{"deli",			3,cFood},
	//Puzzles 10-14:
	{"star wars",			1,cTV},
	{"nucleus",			2,cScience},
	{"animaniacs",			2,cTV},
	{"cell",			1,cScience},
	{"soda",			1,cFood},
	//Puzzles 15-19:
	{"lasagna",			1,cFood},
	{"planet",			1,cScience},
	{"meteor",			2,cScience},
	{"nintendo",			1,cGame},
	{"sega genesis",		1,cGame},
	//Puzzles 20-24:
	{"wheel of fortune",		1,cGame},
	{"jeopardy",			1,cGame},
	{"i love lucy",			2,cTV},
	{"microscope",			2,cScience},
	{"binoculars",			2,cScience}
};





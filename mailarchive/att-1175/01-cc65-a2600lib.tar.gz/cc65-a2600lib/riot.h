// File        : riot.h
// Version     : 0.0
// Description : cc65 header file for Atari 2600 VCS RIOT
// Author      : Adam Wozniak <adam@cuddlepuddle.org>
// Date        : Tue Mar 26 18:04:32 PST 2002
// 
// This file is part of cc65-a2600lib.
// 
// cc65-a2600lib is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cc65-a2600lib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Foobar; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#ifndef _include_riot_h_
#define _include_riot_h_

struct riot_s {
   unsigned char SWCHA, SWACNT, SWCHB, SWBCNT;
   unsigned char INTIM, RIOT_05, RIOT_06, RIOT_07;
   unsigned char RIOT_08, RIOT_09, RIOT_0A, RIOT_0B;
   unsigned char RIOT_0C, RIOT_0D, RIOT_0E, RIOT_0F;
   unsigned char RIOT_10, RIOT_11, RIOT_12, RIOT_13;
   unsigned char TIM1T, TIM8T, TIM64T, TIM1024T;
   unsigned char RIOT_18, RIOT_19, RIOT_1A, RIOT_1B;
   unsigned char RIOT_1C, RIOT_1D, RIOT_1E, RIOT_1F;
};

#define RIOT (*(struct riot_s *) 0x280)

#endif

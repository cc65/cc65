#include <stdio.h>
#include "cc816.h"
#include "hash.h"

static struct Keyword {
     char *		kw_name;	/* reserved word */
     unsigned char	kw_value;	/* Keyword */
} Keyword[] = {
	{ "asm",		ASM		},
	{ "auto",		AUTO		},
	{ "break",		BREAK		},
	{ "case",		CASE		},
	{ "char",		CHAR		},
	{ "const",		CONST		},
	{ "continue",		CONTINUE	},	
	{ "default",		DEFAULT		},
	{ "do",			DO		},
	{ "double",		DOUBLE		},
	{ "else",		ELSE		},
	{ "enum",		ENUM		},
	{ "extern",		EXTERN		},
	{ "far",		FAR		},
	{ "fastcall",		FASTCALL	},
	{ "float",		FLOAT		},
	{ "for",		FOR		},
	{ "goto",		GOTO		},
	{ "if",			IF		},
	{ "int",		INT		},
	{ "long",		LONG		},
	{ "near",		NEAR		},
	{ "register",		REGISTER	},
	{ "restrict",		RESTRICT	},
	{ "return",		RETURN		},
	{ "short",		SHORT 		},
	{ "signed",		SIGNED 		},
	{ "sizeof",		SIZEOF 		},
	{ "static",		STATIC		},
	{ "struct",		STRUCT		},
	{ "switch",		SWITCH		},
	{ "typedef",		TYPEDEF		},
	{ "union",		UNION		},
	{ "unsigned",		UNSIGNED	},
	{ "void",		VOID		},
	{ "volatile",		VOLATILE	},
	{ "while",		WHILE		}
};
#define KEY_COUNT	(sizeof (Keyword) / sizeof (Keyword [0]))

int main(int argc, char *argv[]) 
{
	struct Keyword *kw_ptr;
	int i;
	int kw_hash[(HASHSIZE+HOST_BPW-1)/HOST_BPW];

	/* Add keywords to the hash table */

	for (kw_ptr=Keyword; kw_ptr->kw_name; kw_ptr++) {
		i = get_hash_key(kw_ptr->kw_name);
		kw_hash[i/HOST_BPW] |= 1 << (i%HOST_BPW);
		printf("Hashed %s\n",kw_ptr->kw_name);
	}
}

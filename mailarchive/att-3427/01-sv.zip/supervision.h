#ifndef SUPERVISION_H
#define SUPERVISION_H

typedef unsigned char byte;
typedef unsigned short word;

#define false 0
#define true !0

typedef struct {
  byte width, height, xpos, ypos;
} SV_LCD;

//extern const SV_LCD *sv_lcd;
#define sv_lcd ((SV_LCD*)0x2000)

typedef struct {
  word delay;
  byte control, timer;
} SV_TONE;

//extern const SV_TONE *sv_right, *sv_left;
#define sv_right ((SV_TONE*)0x2010)
#define sv_left ((SV_TONE*)0x2014)

typedef struct {
  byte volume, timer, control;
} SV_NOISE;

//extern const SV_NOISE *sv_noise;
#define sv_noise ((SV_NOISE*)0x2028)

typedef struct {
  word start;
  byte size, control, on;
} SV_DMA;

//extern const SV_DMA *sv_dma;
#define sv_dma ((SV_DMA*)0x2018)

#define sv_control *(byte*)0x2020

#define sv_bank(nmi,irq_timer,irq_dma,lcd_on, timer_prescale, bank) \
	*(byte*)0x2026=(nmi?1:0)|(irq_timer?2:0)|(irq_dma?4:0)|(lcd_on?8:0) \
	|(timer_prescale?0x10:0)|(bank<<5)

#define sv_video ((byte*)0x4000)
#define sv_timer_count *((byte*)0x2023)

// before enabling them set these vectors
extern void (*nmi_vector)(void);
extern void (*irq_timer_vector)(void);
extern void (*irq_dma_vector)(void);

#endif

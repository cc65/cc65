/*
 * =====================================================================================
 * 
 *        Filename:  ramdisk.c
 * 
 *     Description:  small ramdisk for any extended memory on c64
 * 
 *         Version:  1.0
 *         Created:  21.08.2006 13:08:44 CEST
 *        Revision:  none
 *        Compiler:  gcc
 * 
 *          Author:   (), 
 *         Company:  
 * 
 * =====================================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <em.h>
#include <conio.h>
#include <string.h>
//#include <cbm.h>


const char info[] = 	"\n\n---------------------------------------"
			"\nAnother test program for the extended"
			"\nmemory driver C64-RRR.emd (or any other"
			"\nem-driver)\n"
			"\nIt loads a file block-wise and stores"
			"\nit in extended memory using em_map and"
			"\nem_commit.\n"
			"\nThen it 'loads' the file back to its"
			"\nload adress using em_copyfrom\n"
			"\nhannenz@freenet.de"
			"\nhttp://people.freenet.de/hannenz\n"
			__DATE__
			"\n--------------------------------------\n";

char dn[16];
char file[16];
char s[20];
struct em_copy ec;

int main(){
	unsigned blocks,pages;
	unsigned char *buffer,*b,x;
	FILE *f;

	clrscr();
	puts(info);

	buffer = malloc(8192);
	b = buffer;


	do{
		puts("\nem-driver name (default 'c64-rrr.emd'): ");
		putchar('>');
		gets(s);
		if (!strcmp(s,""))
			strcpy(dn,"c64-rrr.emd");
		else
			strncpy(dn,s,16);
		printf("\nloading driver: %s",dn);
		if ((x = em_load_driver(dn)))
			printf("\nerror #%d",x);
	}while (x);
		
	puts(" ok");
	printf("\ninstalling driver: %s",dn);
	em_install(dn);
	printf("\navailable pages: %d",pages=em_pagecount());
	
	do{
		puts("\ntest file to load (default 'zoo'): ");
		putchar('>');
		gets(s);
		if (!strcmp(s,""))
			strcpy(file,"zoo");
		else
			strncpy(file,s,16);
		printf("\nopening file %s",file);
		if ((f = fopen(file,"rb"))==NULL)
			puts("\nno such file");
	}while (f == NULL);
		
	putchar('\n');
	blocks = 0;
	while (!feof(f)){
		gotox(0);
		printf("now reading block #%3d",blocks);
		if (blocks == pages){
			puts("\nexceeded max. ext memory.\nexiting.");
			fclose(f);
			exit(-1);
		}
		fread(em_use(blocks++),256,1,f);
		em_commit();
	}
	fclose(f);
	
	buffer = em_map(0);
	ec.buf = (void*)(*(unsigned*)buffer);
	ec.offs = 2;
	ec.page = 0;
	ec.count = blocks*256;
	printf("\ntransfering from ext. memory to $%04x",ec.buf);
	puts("\nhit any key to continue");
	cgetc();
	em_copyfrom(&ec);
}


extern void abc_play(char chan, char *score);
extern void abc_metronome(void);
extern void abc_sound(void);

extern char voice1[];
extern char voice2[];
extern char voice3[];
extern char voice4[];

#define FLUTE    "I1T20"
#define TRUMPET  "I2T20"
#define TROMBONE "I3T20"
#define DRUMS    "I4T20"

void main(void)
{
    abc_play(0, FLUTE);
    abc_play(1, TRUMPET);
    abc_play(2, TROMBONE);
    abc_play(3, DRUMS);
    abc_metronome(); // Execute the attribute stuff on all channels
    abc_play(0, voice1);
    abc_play(1, voice2);
    abc_play(2, voice3);
    abc_play(3, voice4);
    while (1) {
		int i;

		abc_metronome();
		abc_sound();
		for (i = 0; i < 100; i++) ; // Some delay, I hope...
    }
}


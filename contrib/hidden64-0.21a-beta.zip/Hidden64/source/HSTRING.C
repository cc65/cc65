#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "hide64.h"

int __fastcall__ hstrlen (char* s)
{
	static int i;
	for (i=0; hidereadb(&s[i]); i++);
	return i+1;
}

void __fastcall__ hstrcpy (char* dest, char* sour)
{
	static int i;
	static char c;
	for (i=0; c=hidereadb(&sour[i]); i++)
		hidewriteb(&dest[i], c);
	hidewriteb(&dest[i++], 0);
}

void __fastcall__ hstrcat (char* dest, char* sour)
{
	static int i;
	i=hstrlen(dest);
	hstrcpy (&dest[i-1], sour);
}

/*int __fastcall__ hstrcmp (const void* dest, const void* sour)
{
	static int i;
	i=hstrlen(sour)-1;
	return hmemcmp(dest, sour, i);
}*/

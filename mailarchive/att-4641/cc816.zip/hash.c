#include "hash.h"

unsigned int get_hash_key(char *sp)
{
	unsigned int hash = 0;

	for (; *sp; sp++) {
		hash += hash;
		hash += *sp;
	}

	return (hash % HASHSIZE);
}



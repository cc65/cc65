#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "hide64.h"

int __fastcall__ hstricmp (const void* p1, const void* p2)
{
	static char* p1a,* p2a;
	p1a=p1; p2a=p2;
	for (; tolower(hidereadb(p1a))==tolower(hidereadb(p2a)) && hidereadb(p1a); )
	{
//putchar('.');
		++p1a; ++p2a;
	}
//putchar (13);
	return tolower(hidereadb(p1a))-tolower(hidereadb(p2a));
}


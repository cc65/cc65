#include <stdio.h>
#include "simpleio.h"

void main()
{
	prints ("Testing, 1, 2, 3, testing!\n");
	printc ('.');
	printcr ();
	printu (0); printcr();
	printu (401); printcr();
}

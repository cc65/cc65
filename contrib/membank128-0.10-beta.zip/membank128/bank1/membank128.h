#ifndef __cc65_C128_Bank1_H
#define __cc65_C128_Bank1_H

#include <stddef.h>

//----------------------------------------------------------------------
// Quick access:
//----------------------------------------------------------------------

/* Read value from Bank 1. */
unsigned char __fastcall__ bank1_readbyte (void*);
unsigned int __fastcall__ bank1_readword (void*);

/* Write value to Bank 1. */
void __fastcall__ bank1_writebyte (void*, unsigned char);
void __fastcall__ bank1_writeword (void*, unsigned int);

/* Bank 15 I/O port access: */
unsigned char __fastcall__ readbank15 (void* addr);
unsigned char __fastcall__ writebank15 (void* addr, unsigned char val);

//----------------------------------------------------------------------
// Basic memory functions:
//----------------------------------------------------------------------
/* Copy a data block from Bank 0 to Bank 1 */
void __fastcall__ bank1_memcpyto (void* dest, void* sour, unsigned len);
/* Copy a data block from Bank 1 to Bank 0 */
void __fastcall__ bank1_memcpyfrom (void* dest, void* sour, unsigned len);
/* Copy a data block in Bank 1 */
void __fastcall__ bank1_memcpyin (void* dest, void* sour, unsigned len);

/* Set file name and read/write banks for CBM file routines */
void __fastcall__ cbm_k_setbnk (unsigned char readbank, unsigned char namebank);

void* __fastcall__ bank1_memset (void* s, int c, size_t count);
void __fastcall__ bank1_bzero (void* s, size_t count);
//----------------------------------------------------------------------
// Bank 1 string operations:
//----------------------------------------------------------------------
int __fastcall__ bank1_strlen (char* s);
char* __fastcall__ bank1_strcpyin (char* dest, char* sour);
char* __fastcall__ bank1_strcpyto (char* dest, char* sour);
char* __fastcall__ bank1_strcpyfrom (char* dest, char* sour);
void __fastcall__ bank1_print (const char* s);


//----------------------------------------------------------------------
// Bank 1 File Access:
//----------------------------------------------------------------------
unsigned __fastcall__ bank1_cbm_read	(unsigned char lfn,
					void* buffer,
					unsigned len);
unsigned __fastcall__ bank1_cbm_write	(unsigned char lfn,
					void* buffer,
					unsigned len);
unsigned int bank1_cbm_load(const char* name, unsigned char device, void* data);
unsigned char bank1_cbm_save(const char* name, unsigned char device,
                       const void* data, unsigned int size);

#endif


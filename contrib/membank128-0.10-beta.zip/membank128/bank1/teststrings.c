#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include <c128.h>

#include "membank128.h"
#pragma rodata-name ("B1RODATA")
#pragma data-name ("B1DATA")
#pragma bss-name ("B1BSS")

char s1[]="Welcome to Mars!\n";
char s2 [32];

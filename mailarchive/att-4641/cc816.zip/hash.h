#define HASHSIZE	300

unsigned int get_hash_key(char *sp);

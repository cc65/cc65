

void __fastcall__ prints(char*);

static char o[7];

void __fastcall__ printu (unsigned i)
{
	register char p=6;
	o[6]=0;
	do {
		o[--p]=(i%10)+'0';
		i/=10;
	} while (i);

	//--p;
	prints(&o[p]);
}

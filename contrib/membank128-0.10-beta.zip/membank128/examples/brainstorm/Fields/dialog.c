#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include "dialog.h"
#ifdef __ATARI
#define CH_ENTER CH_EOL
#endif

#pragma bss-name ("TAPEBSS")
/* Define colors to field editing routines */
char diaHilightCol, diaFieldCol
#ifndef __Fields_NoHelp__
	, diaHelpCol
#endif
;

//Set screen columns for different computers:
#define __Columns 79
//Now rows:
#if defined __APPLE2__ || defined __APPLE2ENH__ || defined __ATARI__
#define __Rows 24
#else
#define __Rows 25
#endif


/* Entry point for fields handler. */
unsigned char __fastcall__ dialog (fldenv* f)
{
	//char x,y;			/* Tmp. coordinates. */
	signed char center;		/* Left x coordinate for centering title. */

	unsigned char i;//int i;
	char c[12];
	field *ff;
	unsigned char r=0;
	unsigned char nf=f->numfields-1;
	/* Get screen size and clear. */
	clrscr();

	/* Center title text and print at top of the screen. */
	center=(__Columns-strlen(f->title))>>1; if (center<0) center=0;
#ifdef __COLOR__

	/* Set colors for field editor. */
	diaFieldCol=f->color; diaHilightCol=f->actcolor;
#ifndef __Fields_NoHelp__
	diaHelpCol=f->helpcol;
#endif
#endif
#ifdef __COLOR__
	textcolor(f->titlecol);
#endif
	revers(1); cputsxy (center,0,f->title); revers(0);

	/* Print help. */
#ifndef __Fields_NoHelp__
#ifdef __COLOR__
	textcolor(diaHelpCol);
#endif
	// The following line was changed by Greg King. */
	//gotoxy (0,__Rows-1); cputs(f->globalhelp);
	cputsxy (0,__Rows-1,f->globalhelp);
#endif
	/* Print field data. */
	for (i=0; i<=nf; ++i)
	{
		ff=f->field[i];
		/* Print field label. */
#ifdef __COLOR__
		textcolor (f->lblcolor);
#endif
		cputsxy (ff->lx, ff->ly, ff->label);

		/* Print field data. */
#ifdef __COLOR__
		textcolor (diaFieldCol);
#endif
		gotoxy (ff->x, ff->y);
		switch (ff->type)
		{
		case fldtText:
			cputs (ff->data.text);
			break;
		case fldtNum:
			itoa(*ff->data.num,c,10);
			cputs (c); break;
#ifndef __Fields_NoSel__
		case fldtSel:
			cputs (ff->data.sel.values[*ff->data.sel.sel]); break;
#endif
#ifndef __Fields_NoChk__
		case fldtChk:
			cputc (*ff->data.num?'X':' '); break;
#endif
#ifndef __Fields_NoMoney__
		case fldtMoney:
			printmoneyhere (ff); break;
		}
#endif
	}
	/* Prepare to start dialog data loop. */
	i=0; /* Set current field to # 0. */
	while (!r)
	{
		/* Edit current field and get action. */
		switch (InField(f->field[i]))
		{
		case 0: /* If cursor up, */
			/* move up one field (wrap-around). */
			//if(i<=0) i=nf;
			//else --i;
			if (--i==0xFF) i=nf;
			break;
		case 1: /* If down, */
			/* move down one field. */
			if (++i>nf) i=0;
			//else ++i;
			break;
		case 2: /* If cancel, exit cancelled. */
			r=2; break;
		case 3: /* If continue, exit continue. */
			r=1; break;
		}
	}
	return r-1;
}


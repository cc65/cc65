#ifndef __MemB128Demo_BrainStm_Env_H
#define __MemB128Demo_BrainStm_Env_H


enum mainmenu_
{
	mnuIn,
	mnuLoad,
	mnuSave,
	mnuList,
	mnuWriteR,
	mnuExit
};
unsigned char MainMenu ();

enum speech {
	sNoun,
	sVerb,
	sAdv,
	sAdj
};
enum subspeech {
	sNounPlace = 0,
	sNounPerson,
	sNounAnimal,
	sNounThing
};
extern char* speechtext [4];
void GetWordEntry();
void ListWords ();

#define wordslimit 256
extern unsigned numwords;

extern struct word {
	char word[20];
	enum speech s;
	//enum subspeech subs;
	//unsigned attrib [4];
	//char desc[20];
	
} words [wordslimit], tmpw;

extern struct numparts {
	unsigned nouns,
		 verbs,
		 adj,
		 adv;
} numparts;

void __fastcall__ WriteHeader (char* s);
void brainstorm ();

char __fastcall__ GetInput (char* In, char InLen);

void file_load ();
void file_save ();
#endif


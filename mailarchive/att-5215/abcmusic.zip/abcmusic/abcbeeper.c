// The Atari Lynx audio system has 8 registers per audio
// channel that can be programmed to produce different
// waveforms.

#define STEREO_REG       (*(char *)0xfd50)
#define VOLUME_REG(chan) (*(char *)(0xfd20 + 0 + chan * 8))
#define FEED_REG(chan)   (*(char *)(0xfd20 + 1 + chan * 8))
#define OUT_REG(chan)    (*(char *)(0xfd20 + 2 + chan * 8))
#define SHIFT_REG(chan)  (*(char *)(0xfd20 + 3 + chan * 8))
#define BKUP_REG(chan)   (*(char *)(0xfd20 + 4 + chan * 8))
#define CTLA_REG(chan)   (*(char *)(0xfd20 + 5 + chan * 8))
#define CNT_REG(chan)    (*(char *)(0xfd20 + 6 + chan * 8))
#define CTLB_REG(chan)   (*(char *)(0xfd20 + 7 + chan * 8))

// This table is used to cover the delays needed for 4 octaves
// These values work when the looplen is 2, 4, 8, 16...
static char delays[] = {
	 239, // C,
         225, // ^C, _D,
         213, // D,
         201, // ^D, _E,
         190, // E,
         179, // F,
         169, // ^F, _G,
         159, // G,
         151, // ^G, _A,
         142, // A,
         134, // ^A, _B,
         127, // B,
         119, // C
         113, // ^C _D
         106, // D
         100, // ^D _E
          95, // E
          89, // F
          84, // ^F _G
          80, // G
          75, // ^G  _A
          71, // A
          67, // ^A _B
          63, // B
          60, // c
          56, // ^c _d
          53, // d
          50, // ^d _e
          47, // e
          45, // f
          42, // ^f _g
          40, // g
          38, // ^g _a
          36, // a
          34, // ^a _b
          32, // b
          30, // c'
          28, // ^c' _d'
          27, // d'
          25, // ^d' _e'
          24, // e'
          22, // f'
          21, // ^f' _g'
          20, // g'
          19, // ^g' _a'
          18, // a'
          17, // ^a' _b'
          16 // b'
};

#define NR_OF_CHANNELS 4

#define ABC_FLUTE 1
static int flute[] = {
	0x0001, // taps
	0x0001, // backup
	4,      // octave
	0       // intergrate
};

#define ABC_TRUMPET 2
static int trumpet[] = {
	0x0008, // taps
	0x0096, // backup
	2,      // octave
	1       // intergrate
};

#define ABC_TROMBONE 3
static int trombone[] = {
	0x0008, // taps
	0x0096, // backup
	3,      // octave
	1       // intergrate
};

#define ABC_DRUMS 4
static int drums[] = {
	0x0129, // taps
	0x052e, // backup
	4,      // octave
	0       // intergrate
};

static void set_sound_engine(
	char chan,
    int *settings)
{
	int taps, backup;
	char octave, integrate;
	taps = settings[0];
	backup = settings[1];
    octave = settings[2];
	integrate = settings[3];

    VOLUME_REG(chan) = 0;

    STEREO_REG = 0;

    // Disable count
    CTLA_REG(chan) = 0x10;

    // Setup new sound engine
    FEED_REG(chan) = (taps & 0x1f) + ((taps >> 1) & 0xe0);
    BKUP_REG(chan) = 100; // Very high note, hopefully outside of what you hear
    SHIFT_REG(chan) = backup & 0xff;
    CTLB_REG(chan) = (backup >> 4) & 0xf0;
    CTLA_REG(chan) = ((taps & 0x20) << 2) +
	0x18 + // Enable count
	octave +
	(integrate << 5);

    VOLUME_REG(chan) = 64;
}

void abc_setinstrument(char chan, int instrument)
{
	int *instr;
	switch (instrument) {
	case ABC_FLUTE:
        instr = flute;
		break;
	case ABC_TRUMPET:
        instr = trumpet;
		break;
	case ABC_TROMBONE:
        instr = trombone;
		break;
	case ABC_DRUMS:
        instr = drums;
		break;
	}
    set_sound_engine(chan, instr);
}

void abc_note(char chan, int height, int note_duration)
{
    BKUP_REG(chan) = delays[height + 12]; // Set the timer reload value
    VOLUME_REG(chan) = 64;
}

void abc_rest(char chan, int note_duration)
{
    VOLUME_REG(chan) = 0;
}

void abc_setvolume(char chan, int volume)
{
    VOLUME_REG(chan) = (char)volume;
}

// This is just a helper function if the Audio hardware cannot
// take care of playing the sound without CPU help.
// If I want to use envelopes for notes I need to call this
// routine once whenever I call the abc_metronome routine.
void abc_sound(void)
{
}


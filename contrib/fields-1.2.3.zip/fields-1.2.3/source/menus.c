#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include <conio.h>

#include "menus.h"
#include "dialog.h"
//#include "diaglobal.h"

#ifdef __ATARI__
#define CH_ENTER CH_EOL
#endif

//-----------------------------------------------------------------

//Set screen columns for different computers:
#if defined __APPLE2ENH__ || defined __C128__ || defined __CBM610__
#define __Columns 80
#else
#define __Columns 40
#endif

//-----------------------------------------------------------------
// Define color display routines for color computers:
#ifdef __COLOR__
//unsigned char menucolor, menuhicolor;
static void WHi() //Set menu highlight color:
{
	textcolor (menuhicolor);
	//revers(1);
	reverson();
}
static void WBck() //Set menu color:
{
	//revers(0);
	reversoff();
	textcolor (menucolor);
}
#else
#define WHi() reverson()//revers(1)
#define WBck() reversoff()
#endif

static unsigned char  	top,		/* Top of menu. */
			numops;		/* # options in menu. */
static unsigned char	leftwindow;	/* X coordinate of left text
					 * pos. in menu */
static unsigned char	widwindow;	/* Width inside menu */
static unsigned char	/*x, y,*/ lp;

/* Display menu item text in item at y lines from top inside
 * menu. */
//static void __fastcall__ DispMenuOp (unsigned char y, char* item)
//{
////        cclearxy (leftwindow, y, widwindow);
////        cputsxy (leftwindow, y, item);
//	DrawField (leftwindow, y, widwindow, item);
//}

/* Draws a border around an area of the screen.
 * Starts at (xloc, yloc) and draws a window of size (xlen, ylen).
 */
void __fastcall__ drawborder (unsigned char xloc,
	unsigned char yloc,
   	unsigned char xlen,
	unsigned char ylen)
{
	unsigned char r=xloc+xlen-1,b=yloc+ylen-1;
	/* Draw a border using graphics characters under a CBM computer. */
#ifdef __COLOR__
	textcolor (menuhicolor);
#endif
#if defined(__CBM__) //|| defined (__ATARI__)
	reversoff ();
	/* Draw bottom window border. */
	chlinexy (xloc, yloc, xlen);
	chlinexy (xloc, b, xlen);
	/* Draw left and right sides. */
	cvlinexy (xloc, yloc,ylen);
	cvlinexy (r, yloc,ylen);

	/* Draw corners. */
	cputcxy (xloc, yloc, 0xB0); /* Top-left corner char. */
	cputcxy (r, yloc, 0xAE); /* Top-right corner char. */
	cputcxy (xloc, b, 0xAD); /* Bottom-left corner char. */
	cputcxy (r, b, 0xBD); /* Bottom-right corner char. */
	/* Draw a border of inverted spaces for an Apple computer. */
#elif defined __APPLE2__ || defined __APPLE2ENH__ || defined (__ATARI__)
	unsigned char l;
	reverson();
	/* Draw top. */
	cclearxy (xloc, yloc, xlen);
	/* Draw bottom. */
	cclearxy (xloc, yloc+ylen-1, xlen);
	/* Draw left and right. */
	for (l=0; l<ylen-1; ++l) {
		cputcxy (xloc, yloc+l, ' ');
		cputcxy (xloc+xlen-1, yloc+l, ' ');
	}
	reversoff ();
#endif
}

/* Display pull-down menu with options in menuitems[] at (xloc, yloc) in
 * specified len. and get # selection from user.
 * xlen and ylen are assumed to be correct.
 * This routine doesn't clear the screen.
 */
unsigned char __fastcall__ pulldown (char** menuitems,
	unsigned char xloc,
	unsigned char yloc,
	unsigned char xlen,
	unsigned char ylen)
{
	/* Tmp. variable. */
	unsigned char i;
	unsigned char 	s=0;//,	/* Current selection. */
			//sold=0;	/* Prev. selection. */
	top=yloc+1;		/* Top of menu. */
	numops=ylen-2;//yloc-1;	/* # options in menu. */
	leftwindow=xloc+1;
	widwindow=xlen-2;

	//textcolor (menuhicolor);//WHi();
#ifdef __COLOR__
	//WHi();
	
#endif
	//revers(0);
	/* Draw the border around the menu. */
	drawborder (xloc,yloc,xlen,ylen);
	/* Color of menu background. */
	/* User: change text color as desired. */
	/* Write menu options.  xlen and ylen are assumed to be correct. */
	while (1)
	{
		WBck();
		//for (i=top; i<yloc+ylen-1;++i)
		for (i=top; i<top+numops;++i)
		{
		/* Clear menu line. */
		/* Write menu option. */
			//DispMenuOp (i, menuitems[i-top]);
			DrawField (leftwindow, i, widwindow, menuitems[i-top]);

		}
		//s=0;
		/* Set menu disply color and reverse mode for current menu
		 * option. */
		/* User: change text color as needed. */
		WHi();
		//revers(1);
		//DispMenuOp (s+top, menuitems[s]);
		DrawField (leftwindow, s+top, widwindow, menuitems[s]);
		//i=cgetc();
		/* Menu background color. */
		/* User: make sure the color value in the next line is the
		 * same as above menu background color. */
		switch (cgetc())
		{
	        case CH_CURS_UP:
			//if (s==0) s=numops;
			//--s;
			//if (--s==0xFF) s=numops-1;
			if ((signed char) --s<0) s=numops-1;
			//s=(--s)%numops;
			break;
        	case CH_CURS_DOWN:
			//++s;
			//if (s>=numops) s=0;
			//if (++s>=numops) s=0;
			s=(++s)%numops;
			break;
		case CH_ENTER:
			//revers (0);
			//clearwin (xloc, yloc, xlen, ylen);
			return s;
		case CH_ESC:
#ifdef CH_STOP
		case CH_STOP:
#endif
			//revers (0);
			//clearwin (xloc, yloc, xlen, ylen);
			reversoff();
			//for (i=yloc; i<yloc+ylen; ++i)
			//	cclearxy (xloc, i, xlen);
			//clrscr();
			return -1;
		}
		//sold=s;
	}
}
#ifndef __Fields_NoMainMenu__
//static unsigned char mxlen, mperx;
//void __fastcall__ WriteM (unsigned char e, char* s)
//{cputsxy ((e%mperx)*mxlen, e/mperx, s);}
unsigned __fastcall__ mainmenu (struct mainmenuops* m)
{
	unsigned char x=0, y=0;//, lp=0;
	//unsigned char x, y;//, lp;
	unsigned char mxlen=m->xlen, mperx=__Columns/mxlen;//m->xlen;
	unsigned char l=m->numitems;
	unsigned char /*i=0,*/ j, r;
	struct menuitemops* m2;
	//unsigned char x, y;
	/*x=y=0;*/ lp=0; //mxlen=m->xlen, mperx=__Columns/m->xlen;
	//int c;
	//unsigned char c;
//#ifdef __COLOR__
//	menucolor=m->color;
//	menuhicolor=m->hicolor;
//#endif
	//i=0;
	//clrscr();
	while (1)
	{
		WBck();
		clrscr();
		m2=m->m[lp];
		for (j=0; j<l; ++j)
			cputsxy ((j%mperx)*mxlen, j/mperx, m->m[j]->name);
			//WriteM (j, m->m[j]->name);
		WHi();
		cputsxy ((lp%mperx)*mxlen, lp/mperx, m2->name);
		//WriteM (lp, m2->name);
		//c=cgetc();

		//WBck();
		//revers(0);
		//cputsxy ((i%mperx)*xlen, i/mperx, m2->name);
		//switch (c)
		switch (cgetc())
		{
		case CH_CURS_LEFT:
		case CH_CURS_UP:
			//--i;
			//if (--lp==0xFF) lp=l-1; break;
			if ((signed char) --lp<0) lp=l-1; break;
			//i=(i-1)%l; break;
		case CH_CURS_RIGHT:
		case CH_CURS_DOWN:
			//++i;
			//if (i>=l/*m->numitems*/) i=0; break;
			if (++lp>=l/*m->numitems*/) lp=0; break;
			//++lp; if (lp>=l/*m->numitems*/) lp=0; break;
			//lp=(lp+1)%l; break;
#ifdef CH_STOP:
		case CH_STOP:
#endif
		case CH_ESC:
			reversoff();
			return -1;
		case CH_ENTER:
			x=mxlen*(lp%mperx); //y=lp/mperx+1;
			if (x+mxlen>__Columns) x=__Columns-m2->xlen;
			//r=pulldown (m2->menuitems, x,y, m2->xlen,m2->ylen);
			r=pulldown (m2->menuitems, x, lp/mperx+1, m2->xlen,m2->ylen);
			WBck();
			//if (r!=0xFF) return (i<<8)+r;
			if ((signed char) r>=0) return (lp<<8)+r;
			//if (r<0) return (i<<8)+r;
			//if (~r) return (i<<8)+r;
			//cputsxy ((i%mperx)*mxlen, i/mperx, m2->name);
		}
	}
}
#endif

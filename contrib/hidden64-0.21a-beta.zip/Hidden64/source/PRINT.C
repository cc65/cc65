#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <conio.h>

#include <c64.h>

#include "hide64.h"

void __fastcall__ printh (const char* s)
{
	static int i;
	for (i=0; hidereadb(&s[i]); ++i) putchar(hidereadb(&s[i]));
}

/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c64.h>
#include "hide64.h"

#include "words.h"
#include "board.h"

//Store bss data in this module in the tape buffer.
#pragma bssseg ("TAPEBSS")

//This routine prints the status line passed through s to the screen
//at line 7.  It will clear the line first.  Please set the appropriate
//text color and reverse mode as desired.  Used to optimize code.
//Better than writing the output inline.
static void __fastcall__ DispStatus (char* s)
{
	cclearxy (0,7,39);//Clear line.
	gotox (0); printh(s);//Write text.
}

//Select board and returns #.
int selboard () {
	static unsigned i;		//Temp.
	unsigned char c, d;		//c=user key/scan for board.
					//d=scan for board.
	unsigned b=numboards;		//Temp. boards left for scan.
	unsigned curnumpuzzles=numboards;//# puzzles after cate./level exclusion.
	
sb_start:
	//Print prompt to get board category.
	printh (Message[mGetCate]);
	//Write up to nine categories.  More will cause bugs.
	for (i=0; i<numcate; ++i)
	{
		printf ("\x1F%d\x1C. %Hs\n",(int)i+1, hidereadw((void*)&catetext[i]));
	}
	//Wait for appropriate key.
	while ((c=cgetc())-'1'>=numcate&&c!='x');
	if (c=='x') return -1; //If 'x' exit.
	c-='1'; //If digit, convert to number starting at 1.
	//Scan boards.
	curnumpuzzles=numboards;
	for (i=0; i<numboards; ++i)
		//If different category, exclude from list by decrementing #
		//available boards.
		if (hidereadb(&boards[i].cate)!=c) {--curnumpuzzles;}
	//Ask for difficulty level.
#pragma rodataseg (push, "HIDECONST")
	printh ("\nNow select the difficulty level\n"
		"(1-3):\n");
	//Process as before, except starting at 0.
	while ((d=cgetc())-'1'>=3&&d!='x');
	if (d=='x') return -1;
	d-='0';
	//Scan for level in same category.
	for (i=0; i<numboards; ++i) 
		if (hidereadb(&boards[i].cate)==c &&
			hidereadb(&boards[i].level)!=d) {--curnumpuzzles;}
	//Get random puzzle based on # available puzzles in both cate and level.
	b=/*c=*/rand()%curnumpuzzles;
	//Scan puzzles:
	for (i=0; i<numboards;++i) {
		//Read level & cate.
		if (hidereadb(&boards[i].cate)==c &&
			hidereadb(&boards[i].level)==d)
		{
			//If match:
			//If 0 left in board ID (current board in list), return
			//current absolute board #.
			if (b==0) return i;
			//Otherise, advance to next board #.
			--b;
		}
	}
//	//Assume first board.
//	return 0;
	printh ("No matching board found.\n"
		"1=Create at random, 2=retry,"
		"3=exit?\n");
#pragma rodataseg (pop)
	while (1)
	{
		switch (cgetc())
		{
		case '1':
			return rand()%numboards;
		case '2':
			goto sb_start;
		case '3': return -1;
		}
	}	
}
#pragma rodataseg (push, "HIDECONST")
void play ()
{
	static char c;			//key
	int sboard = selboard();	//Current board.
	if (sboard<0) return;		//If -1, quit (no board selected).
	//Draw board on screen.
	drawboard(sboard);
	//Main player loop.
	while (1)
	{
		//Prompt user for a letter.
		//textcolor (0); gotoxy (0,8); puts ("Guess a letter.           ");
		gotoy (7); printh ("\n\x90Guess a letter.");
		c=cgetc();
		//Process escape.
		if (c==CH_STOP) {
			//cputsxy (0,8,"Abort game (y\n)?          ");
			DispStatus ("\x1c""Abort game (y\n)?\n");
			while ((c=cgetc())!='y' && c!='n');
			if (c=='y') return;			//If yes, exit.
			continue;				//If no, loop.
		//Process letter.
		} else if (islower(c)) {
			//Guess letter.
			c=guessletter(c);
			//Default color red just in case.
			textcolor (2);
			//If c=0, special handling not necessary as the letter is good.
			switch (c) {
			case 0:
				DispStatus ("");
				break;
			case 1:
				//Board solved.
				DispStatus ("\x1E\x12      You WIN!        \n");
				printh ("\nPress any key to exit...\n");
				cgetc();
				return;
			case 2:
				//Letter taken.
				DispStatus ("Choose another letter.\n");
				break;
			case 3:
				//Out of letters--player loses.
				DispStatus ("Game Over!\n");
				printh ("\nPress any key to exit...\n");
				cgetc();
				return;
			}
		}
	}
}
#pragma rodataseg (pop)

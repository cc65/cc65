/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#include <conio.h>

#include <c128.h>
#include <membank128.h>
#include "dialog.h"

#include "env.h"

#pragma data-name ("APPDATA")
#pragma rodata-name ("APPCONST")
#pragma code-name ("APPCODE")
#pragma bss-name ("TAPEBSS")

void __fastcall__ WriteHeader (char* s)
{
	//static char center;
	//center=(80-strlen(s))>>1;
	clrscr();
	gotox (33); puts ("\x96\x12""BrainStorm 128\x92\x90");
	//gotox (center); printf ("\x1E%s\x90\n",s);
	gotox ((80-strlen(s))>>1); printf ("\x1E%s\x90\n",s);
	gotox (21); puts ("by \x99Joseph Rose\x90, a.k.a. \x9AHarry Potter\x90");
	chline (80); /*putchar (13); */textcolor (0);
}
char* speechtext [4]=
{
	"noun",
	"verb",
	"adjective",
	"adverb"
};

//Place the definition for the struct to hold the settings
//or database entry here.
field fWord = {
	//Location and size of field:
	10,3,20,
	//Location and name of lebel:
	0,3,"Word:",
	fldtText, //Field type
	"Type word here."
};
field fSpeech = {
	//Location and size of field:
	10,4,12,
	//Location and name of lebel:
	0,4,"Speech:",
	fldtSel, //Field type
	"Select part-of-speech here."
};
//static field* fldptrs [2] = {&fWord, &fSpeech};
fldenv dia = {
	//Screen colors:
	0,2,10,5,0,
	//Title:
	"BrainStorm 128 - Enter Vocabulary Word",
	"Help text",
	//Number of fields, followed by references to fields:
	2,{&fWord, &fSpeech}
};


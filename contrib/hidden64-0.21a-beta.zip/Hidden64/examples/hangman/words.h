#ifndef __Hidden64_Ex1_Hangman_WordData_H
#define __Hidden64_Ex1_Hangman_WordData_H

extern const unsigned char numboards;
extern const unsigned char numcate;
enum cate{
	cPhrase,
	cGame,
	cTV,
	cScience,
	cFood
};
extern char * catetext[];
extern struct boards {
	char* board;
	unsigned char level;
	unsigned char cate;
} boards [];
//extern struct boards curboard;

#endif

                                VicText Demo
                               by Joseph Rose,
                             a.k.a. Harry Potter
                             -------------------

[Description]

        VicText is a demo that displays text bouncing between the top and
bottom of the screen.  The text is in rainbow colors.  It is compilable 
for the unexpanded Vic-20..  I used GenCartVic to create it.  The file
TEXTVIC.CRT is the binary.  The file MAIN.C is the only source included in
the product and does the demo.  vc.* are files from the GenCartVic library.
To compile, use cl65 to compile the MAIN.C module for the unexpanded
Vic-20.  If I remember correctly, I used the -Oi switch to optimize the
module.

[Feedback]

        If you have any questions or comments about this software, please
contact me via e-mail at maspethrose7@aol.com.  If you do so, please start
the subject with "To Joseph:" as I currently share my e-mail address.
If you like or dislike this software, please tell me.  I'd appreciate any
feedback.

[Copyright]

        You may use and modify this program as desired.  If you plan to
give this program to another, you MUST include all files INTACT and UNMODI-
FIED and honor the original author as the creator of the software.  You may
derive software from VicText.  If you do so, you MUST honor the author as
the creator of the original software and tell the author of such derivation.
/***********************************************************************
 * 
 * Individual module for the cc65 compiler.
 *
 * The template for this file was created by TempC Module Creator by
 * Joseph Rose.  This template can be used in your programs, provided
 * you mention TempC in your software's documentation.  If this source
 * code is distributed, this copyright must be included in the file.
 *
 ***********************************************************************/

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

#include <c128.h>

#include "membank128.h"
#include "env.h"

#include <menus.h>

extern char* mtext[];
#pragma code-name ("APPCODE")
unsigned char MainMenu ()
{
	//clrscr(); gotox (30); puts ("\x96\x12""BrainStorm 128\x92\x90");
	//gotox (32); puts("\x1EMain Menu\x90");
	//gotox (18); puts ("by \x99Joseph Rose\x90, a.k.a. \x9AHarry Potter\x90");
	//chline (78);
	WriteHeader ("Main Menu");
	return pulldown (mtext, 
			20, 5,
			32, 8);
}
#pragma rodata-name ("APPCONST")
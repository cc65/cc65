#ifndef CC816_H
#define CC816_H

/* Some basic system defaults */

#define HOST_BPW	16	/* Host bits per word */
#define HOST_CPW	2	/* Host characters per word */
#define TARGET_BPW	16
#define	TARGET_CPW	2


/* This is the maximum size for the buffers */

#define MAX_BUF 255

/* This enumerates the symbols that the parse routine uses when
   figuring out what symbol has been read.
 */

typedef enum keyword_t {
  /* C reserved words */
     ASM,
     AUTO,
     BREAK,
     CASE,
     CHAR,
     CONST,
     CONTINUE,
     DEFAULT,
     DO,
     DOUBLE,
     ELSE,
     ENUM,
     EXTERN,
     FAR,
     FASTCALL,
     FLOAT,
     FOR,
     GOTO,
     IF,
     INT,
     LONG,
     NEAR,
     REGISTER,
     RESTRICT,
     RETURN,
     SHORT,
     SIGNED,
     SIZEOF,
     STATIC,
     STRUCT,
     SWITCH,
     TYPEDEF,
     UNION,
     UNSIGNED,
     VOID,
     VOLATILE,
     WHILE,
} keyword_t;

#endif	/* CC816_H */

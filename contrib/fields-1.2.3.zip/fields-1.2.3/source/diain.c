#include <string.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>
#include <ctype.h>
#include <conio.h>

#ifdef __CBM__
#include <cbm.h>
#endif
#ifdef __APPLE2__
#include <apple2.h>
#endif
#ifdef __APPLE2ENH__
#include <apple2enh.h>
#endif
#ifdef __ATARI__
#include <atari.h>
#define CH_ENTER CH_EOL
#endif

#include "dialog.h"

void HelpCol (void);

//static and __fastcall__ declarations recommended by Greg King.
/* Import colors for field-editing routines. */
extern char diaHilightCol, diaHilightCol;
#ifndef __Fields_NoHelp__
extern char diaHelpCol;
#endif
//Define color macros:
//selcolor() = Color(s) for selected text.
//unselcolor() = Color(s) for normal text.

//For computers with colors:
#ifdef __COLOR__
void selcolor (void)
{
	textcolor (diaHilightCol);
	reverson();
}
void unselcolor(void)
{
	reversoff ();
	textcolor(diaNormalCol);
}
//For computers with no colors:
#else
void selcolor(){
	//revers(1);
	reverson();
}
void unselcolor()
{
	//revers(0);
	reversoff();
}
#endif
//-----------------------------------------------------------------

//Set screen columns for different computers:
#if defined __APPLE2ENH__ || defined __C128__ || defined __CBM610__
#define __Columns 80
#else
#define __Columns 40
#endif
//Now rows:
#if defined __APPLE2__ || defined __APPLE2ENH__ || defined __ATARI__
#define __Rows 24
#else
#define __Rows 25
#endif

static unsigned char tmplen;	//Length for certain fields.  Written by
				//InField() upon call for itself and other
				//functions to save from extra code.
static unsigned char x, y;	//Start coordinates of field entry.  Written
				//once to save code.
static unsigned char r, sx;	//r is the return code by a field function.
				//Set once to save code.
				//sx is used to define the current selection in
				//a selection field and the current pos. in a
				//text/number field.

//Displays the help for the current field type.  Disablable with the given
//define.
#ifndef __Fields_NoHelp__
static void __fastcall__ placehelp (char* s)
{
#ifdef __COLOR__
	HelpCol();
#endif
	DrawField (0,__Rows-3,__Columns,s);
}
#endif

static void __fastcall__ DrawInFieldStatic (char* s)
{
	DrawField (x, y, tmplen, s);
}
// Following routine has been discontinued by recommendation of Greg King.
/*void EmptyField (unsigned x, unsigned y, unsigned len)
{
	gotoxy (x,y);
	for (;len>0;--len) cputc (32);
}*/

//-------------------------------------------------------------------
//
// Handle money field:
//
#ifndef __Fields_NoMoney__
void __fastcall__ printmoneyhere (field* f)
{
	static char m[16]="$%2.2ld.%02.2ld";
	unsigned long *n=(unsigned long) f->data.lnum;
	m[2]=m[4]=(f->len-5)+'0';
	gotoxy (f->x,f->y);
	cprintf (m,*n/100, *n%100);
}

static unsigned char __fastcall__ InMoneyField (field* f)
{
	unsigned char c;
	long *x=f->data.lnum;
#ifndef __Fields_NoHelp__
	//Write help.
	placehelp ("Type in price, as in a calculator");
#endif
	//Set selection color.
	selcolor();
	
	do {
		//Display current amount.
		printmoneyhere(f);
		//Get key.
		c=cgetc();
		//Insert digit if digit.
		if (isdigit(c))		//m=m*10+(c-'0');
			*x=*x*10+(c-'0');
		//Test value against controls (Untrapped if #):
		switch (c){
		//Delete right-most digit if back-space.
		case CH_DEL:
			*x/=10; break;
		//If accept (Enter), exit loop with Enter code (4).
		//(I use an incremetal technique to save from extra breaks.)
#ifdef CH_EOL
			case CH_EOL:
#else
			case CH_ENTER:
#endif
				++r;
			//Cancel code (3).
#ifdef CH_STOP
			case CH_STOP:
#endif
			case CH_ESC:
				++r;
		//Go to next field.
		case CH_CURS_DOWN: 	++r;
		//Go to prev. field.
		case CH_CURS_UP: 	++r; break;
		}
	} while (!r); //Loop until exit code set.
	//Unhilight and print final $.
	unselcolor ();
	printmoneyhere(f);
	return r-1; //Return corrected value (0-indexed) of exit code.
}
#endif

//-------------------------------------------------------------------
//
// Handle check field:
//

#ifndef __Fields_NoChk__
//This array quickens the display of the current check box state by
//offsetting the value into this array.  (1 is assumed to always be
//true.
const char ChkArray[2]=" X";

//Displays check at current location on the screen:
static void __fastcall__ WriteChkHere (unsigned char i)
{cputcxy(x, y,ChkArray[i]);}


static unsigned char __fastcall__ InChkField (field* f)
{
	unsigned char i=*f->data.byte;
	//unsigned char r=0;
	/*unsigned char*/ //--r;//r=-1;
	//char c;
	//unsigned char x=f->x, y=f->y;
#ifndef __Fields_NoHelp__
	placehelp ("Up/down:move Space:toggle Enter: cont.");
#endif
	selcolor();

	do
	//while (!r)
	{
		//j=(i?'X':' ');
		//cputcxy (x, y, i?'X':' ');
		WriteChkHere (i);
		//WriteChkHere (i);
		//putchere (j);
		//DrawInFieldStatic (j);//i?'X':' ');
		/* Process. */
		switch (cgetc())//(c)
		{
		/* Exit good if enter key pressed. */
		//case ' ': i=!i; break;
		case ' ': i^=1; break;
//		case CH_ENTER: ++r;
//		case CH_CURS_DOWN:
//			++r; //break;
//		case CH_CURS_UP:
//			++r; break;
#ifdef CH_EOL
		case CH_EOL:
#else
		case CH_ENTER:
#endif
			++r;
#ifdef CH_STOP
		case CH_STOP:
#endif
		case CH_ESC:
			++r;
		case CH_CURS_DOWN: ++r;
		case CH_CURS_UP:   ++r; break;
		}
	} while (!r);
	//while ((signed char)r<0);
	unselcolor();
	*f->data.byte=i;
	//cputcxy (x, y,i?'X':' ');
	WriteChkHere (i);
	//WriteChkHere (i);
	//putchere (j);//DrawInFieldStatic (j);//i?'X':' ');
	//WriteInChkField (f);
	return r-1;
}
#endif


#ifndef __Fields_NoSel__
/*void __fastcall__ WriteInSelField (field* f)
{
	//DrawField (f->x, f->y, f->len, f->data.sel.values[*f->data.sel.sel]);
	DrawFI
}*/

//Signed char return type recommended by greg King.
static unsigned char __fastcall__ InSelField (field* f)
{
	// r's initialization was moved
				/* Temp. values. */
	//unsigned char r=0;//-1;
	//flddatasel* d=&f->data.sel;
	char** s=f->data.sel.values;	/* Quick access to selection
					 * values */
	char* scur;
	unsigned char n=f->data.sel.num;
	/*unsigned char*/ sx=*f->data.sel.sel;/* Quick access to # user
					 * selection. */
	//unsigned char x=f->x, y=f->y;
	//unsigned char len=f->len-1;
#ifndef __Fields_NoHelp__
#if __Columns==40
	/* Print field type help for 40-column screen. */
	placehelp ("Left/right:select Up/down:move Enter");
#else
	/* Print field type help for 80-column screen. */
	placehelp ("Left/right:select Up/down:move Enter: continue");
#endif
#endif
	/* Set to selection color. */
	selcolor();
	/* Main routine loop. */
	do
	{
		//scur=s[sx];
		/* Write current user selection. */
		//DrawField (x, y, tmplen, s[sx]);
		//DrawInFieldStatic (s[sx]);
		DrawInFieldStatic (scur=s[sx]);
		/* Get key. */
		// switch modified from orig. by Greg King:
		// * if(incntrl(c) removed.
		// * First four conditions replaced.
		switch (cgetc())//(c)
		{
		/* If cursor left: */
		case CH_CURS_LEFT:
			//decrease field # w/ wrap.
			//if (--sx==0xFF) sx=n-1;
			if ((signed char)--sx<0) sx=n-1;
			break;
		/* If right: */
		case CH_CURS_RIGHT:
			/* Increase selection #. */
			//++sx;
			if (++sx>=n) sx=0;
			//if (sx>=n) sx=0;
			//sx=(++sx)%n;
			break;
		///* If up/down, move to prev. or next field. */
#ifdef CH_EOL
		case CH_EOL:
#else
		case CH_ENTER:
#endif
			++r;
#ifdef CH_STOP
		case CH_STOP:
#endif
		case CH_ESC:
			++r;
		case CH_CURS_DOWN: ++r;
		case CH_CURS_UP:   ++r; break;
		}
	} while (!r);//((signed char) r<0);//(!r);
	/* Draw field in unselected colors. */
	unselcolor();
	//DrawField (x, y, tmplen, s[sx]);
	//DrawInFieldStatic (s[sx]);
	DrawInFieldStatic (scur);
	/* Write selection #. */
	*f->data.sel.sel=sx;
	//*d->sel=sx;
	//WriteInSelField (f);
	/* Exit with return code. */
	return r-1;
}
#endif

#ifndef __Fields_NoHelp__
//static char* InHelp[] = 
//{
//	"Type text. Up/down:move, Enter:continue",
//	"Type #. Up/down:move, Enter:continue"
//};
#endif

unsigned char __fastcall__ InField (field* f)
{
	// Temporary field data
	char in[81];
	unsigned char c;	// Tmp. char
	//unsigned i;		// Tmp. var
	//unsigned char r=0;	// Return value.
	//unsigned char sx;//=0;	// Tmp. x pos. in field
	unsigned char t=f->type, sl;
	unsigned char *ptrchr;
	unsigned char rchar;//, atend;
	tmplen=f->len-1;
	x=f->x, y=f->y;
	r=sx=0;

	//Display help.
#ifndef __Fields_NoHelp__
#ifdef __COLOR__
	//textcolor (diaHelpCol);
	HelpCol ();
#endif
	DrawField (0, __Rows-2,__Columns-1, f->help);
#endif
	//Copy field to temp. field.
	//switch (t)
	switch (t)
	{
#ifndef __Fields_NoSel__
	case fldtSel:	return InSelField (f);
#endif
#ifndef __Fields_NoChk__
	case fldtChk:	return InChkField (f);
#endif
#ifndef __Fields_NoMoney__
	case fldtMoney:	return InMoneyField (f);
#endif
	case fldtText:	strcpy (in,f->data.text);	break;
	//case fldtNum:	
	default:	itoa (*f->data.num, in,10);
	}
	
#ifndef __Fields_NoHelp__
	placehelp (t==fldtText?
		"Type text. Up/down:move, Enter:continue":
		"Type #. Up/down:move, Enter:continue");
	//placehelp (InHelp[t]);
#endif
	// Write field to screen.
#if !defined __APPLE2ENH__ && !defined __APPLE2__
	selcolor();
#endif
	//Main loop for keyboard input.
	do//while (r==-1)
	//while (!r)
	{
		sl=strlen(in); ptrchr=in+sx;
		rchar=80-sx;
		//atend=(sl<tmplen?1:0);
		//curx=x+sx;
		//Get key with cursor.
		//DrawField (x, y, tmplen/*f->len*/, in);
		//gotox (x+sx);
#if defined __APPLE2ENH__ || defined __APPLE2__
		selcolor();//revers (1); 
		//DrawField (x, y, tmplen/*f->len*/, in);
		DrawInFieldStatic (in);
		gotox (x+sx);//x+sx);
		unselcolor();//revers (0);
		if (sx<tmplen) cputc (127);//revers (0); cputc (127); revers (1); 
		c=cgetc();
#elif defined __ATARI__
		c=cgetc();
#else
//*((char*) 0x400)=sx;
		//DrawField (x, y, tmplen/*f->len*/, in);
		DrawInFieldStatic (in);
		gotox (x+sx);//(x+sx);
 		cursor(1);
		c=cgetc();
		cursor(0);
#endif
#if defined __APPLE2__ || defined __APPLE2ENH__
		if (c==127) {
#else
		if (c==CH_DEL) {
#endif
			//if (sx>0) {
			if (sx) {
				//in[strlen(in)]=0;
				--sx;
				/* move the rest of the field left to cover current pos., */
				//memmove (&in[sx], &in[sx+1],81-sx);//strlen(&in[sx]));
				//memmove (&in[sx], &in[sx+1], rchar);//strlen(&in[sx]));
				memmove (ptrchr-1, ptrchr, rchar);//strlen(&in[sx]));
				//memmove (ptrchr, ptrchr+1, rchar);//strlen(&in[sx]));
				//--sx;
				/* and move the cursor left. */
			} continue; //break;
		}
		//If the key is a displayable character
		//(# if field is a number or text if text)
		/*else*/ if (((isdigit(c)||(c=='-'&&!sx))&&t==fldtNum)
		///*else*/ if (((isdigit(c)||(c=='-'))&&t==fldtNum)
			|| (isprint(c)&&t==fldtText)) {
			//ignore if end of field.
			//if (strlen(in)>=tmplen/*f->len*/) continue;
//			if (sl>=tmplen/*f->len*/) continue;
//			//memmove (&in[sx+1], &in[sx],80-sx);
//			memmove (ptrchr+1, ptrchr, rchar);
//			//if (in[sx]==0) in[sx+1]=0;
//			in[sx]=c; //if (sx>=strlen(in))
//			//*ptrchr=c; ++sx;
//			++sx; //continue;
//			//Print char and advance x.
			//if (strlen(in)>=tmplen/*f->len*/) continue;
			if (sl>=tmplen/*f->len*/) continue;
			//memmove (&in[sx+1], &in[sx],80-sx);
			//memmove (&in[sx+1], &in[sx],rchar);
			memmove (ptrchr+1, ptrchr, rchar);
			//memmove (ptrchr+1, &in[sx], rchar);
			//if (in[sx]==0) in[sx+1]=0;
			in[sx]=c; //if (sx>=strlen(in))
			//*ptrchr=c; ++sx;
			++sx;
		//If control character, do:
		}// else /*if (iscntrl(c))*/ {
			//r=-1; /* Set return value to -1 for no exit. */
			switch (c)
			{
			/* Exit loop if enter. */
			//case CH_ENTER: r=2; break;
#ifdef CH_INS	/* Recommended by Greg King. */
			/* If insert key: */
			//case CH_INS:
			//	/* If field not full, */
			//	if (sl<tmplen/*f->len*/) {
			//	//if (in[sx]) {
			//		/* open space for new character, */
			//		//memmove (&in[sx+1], &in[sx],rchar);//strlen(&in[sx]));
			//		//memmove (&ptrchr[1], ptrchr, rchar);//strlen(&in[sx]));
			//		memmove (ptrchr+1, ptrchr, rchar);//strlen(&in[sx]));
			//		/* write space to current pos. */
			//		in[sx]=32;
			//		//ptrchr[0]=32;
			//	} break;
#endif
			/* If delete */
//#if !defined __APPLE2__ && !defined __APPLE2ENH__
//			case 127:
//#else
//			case CH_DEL:
//#endif
//				/* and cursor not at left of field, */
//				if (sx>0) {
//					//in[strlen(in)]=0;
//					--sx;
//					/* move the rest of the field left to cover current pos., */
//					//memmove (&in[sx], &in[sx+1], rchar);//strlen(&in[sx]));
//					memmove (ptrchr, ptrchr+1, rchar);//strlen(&in[sx]));
//					/* and move the cursor left. */
//				} break;
//				/* If cursor left */
			case CH_CURS_LEFT:
				/* and not at left of the screen, move cursor left. */
				if (sx>0) --sx; break;
			/* If cursor right */
			case CH_CURS_RIGHT:
				/* and not at end of field, move cursor right. */
				if (in[sx]) ++sx; continue;//break;
				//if (sx>=sl) ++sx; break;
				//if (*ptrchr) ++sx; break;
			/* If up/down, mark return value for move up/down. */
			//case CH_CURS_UP:
			//	r=0; break;
			//case CH_CURS_DOWN:
			//	r=1; break;
			//break;
#ifdef CH_EOL
			case CH_EOL:
#else
			case CH_ENTER:
#endif
				++r;
#ifdef CH_STOP
			case CH_STOP:
#endif
			case CH_ESC:
				++r;
			case CH_CURS_DOWN: ++r;
			case CH_CURS_UP: ++r; break;
			}
			/* Exit loop if return code set for exit. */
			//if (r!=-1) break;
		//}
	} while (!r);
	//} while (r==0);
	//} while ((signed char) r<0);
	/* Draw field unhilighted. */
#if !defined __APPLE2ENH__ && !defined __APPLE2__
	unselcolor();
#endif
	//DrawField (x, y, tmplen/*f->len*/, in);
	DrawInFieldStatic (in);
	/* Save field information to the field descriptor. */
	//switch (t)
	//{
	/* If text, */
	//case fldtText:
	//if (t==fldtText) {
	//	/* Copy field to memory. */
	//	strcpy(f->data.text, in);
	//	//break;
	///* If #: */
	////default://case fldtNum:
	//} else {
	//	/* convert to int and save. */
	//	*f->data.num=atoi (in);
	//	//break;
	//}
	if (t==fldtText) strcpy(f->data.text, in);
	else *f->data.num=atoi (in);
	return r-1;
}

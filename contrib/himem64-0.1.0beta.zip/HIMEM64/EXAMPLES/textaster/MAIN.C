/**************************************************************************
 *
 * Individual C module created by TempC Small for DOS.
 *
 * The end-user may use this code as he/she likes under the following
 * conditions:
 *
 * 1. TempC, along with its author, is mentioned in the program's 
 *    documentation, and
 * 2. If this source code is published, this header must be kept
 *    intact.
 *
 **************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <stdarg.h>
#include <string.h>

#include <c64.h>
#include <conio.h>

#include "aster.h"

void main ()
{
	bordercolor (2); bgcolor(0);textcolor (12); clrscr();
	putchar (142); //Switch to upper-case mode.

	runboard();
}

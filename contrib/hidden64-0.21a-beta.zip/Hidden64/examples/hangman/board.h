///////////////////////////////////////////////////////////////////////////
//
// Board header for Hangman example program for Hidden64, created by
// Joseph Rose, a.k.a. Harry Potter.
//
///////////////////////////////////////////////////////////////////////////
// 
// Copyright 2011 by Joseph Rose, a.k.a. Harry Potter, distributed under
// the GNU GPL.
//
///////////////////////////////////////////////////////////////////////////

#ifndef __Hidden64_Ex1_Hangman_Board_H
#define __Hidden64_Ex1_Hangman_Board_H

extern unsigned curboardnum;		//Number of current board, defined elsewhere.
extern char board [3][30];		//Board, as on screen, in PETSCII.
extern unsigned long lettersused;	//Letters called, bit 0=A, bit 1=B, etc.
extern unsigned long lettersinboard;	//Letters in the board.
extern unsigned char turnsleft;		//Turns left.
//Reads and draws the board on the screen, board # passed in b.
void drawboard (unsigned b);
unsigned char guessletter (char l);

enum message{
	mWelcome,
	mGetCate
};
extern char* Message[];

void play ();
#endif

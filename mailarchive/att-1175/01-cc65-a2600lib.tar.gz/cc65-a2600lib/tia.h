// File        : tia.h
// Version     : 0.0
// Description : cc65 header file for Atari 2600 VCS TIA
// Author      : Adam Wozniak <adam@cuddlepuddle.org>
// Date        : Tue Mar 26 18:04:32 PST 2002
// 
// This file is part of cc65-a2600lib.
// 
// cc65-a2600lib is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
// 
// cc65-a2600lib is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
// 
// You should have received a copy of the GNU General Public License
// along with Foobar; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

#ifndef _include_tia_h_
#define _include_tia_h_

struct tia_s {
   unsigned char VSYNC, VBLANK, WSYNC, RSYNC;
   unsigned char NUSIZ0, NUSIZ1, COLUP0, COLUP1;
   unsigned char COLUPF, COLUBK, CTRLPF, REFP0;
   unsigned char REFP1, PF0, PF1, PF2;
   unsigned char RESP0, RESP1, RESM0, RESM1;
   unsigned char RESBL, AUDC0, AUDC1, AUDF0;
   unsigned char AUDF1, AUDV0, AUDV1, GRP0;
   unsigned char GRP1, ENAM0, ENAM1, ENABL;
   unsigned char HMP0, HMP1, HMM0, HMM1;
   unsigned char HMBL, VDELP0, VDELP1, VDELBL;
   unsigned char RESMP0, RESMP1, HMOVE, HMCLR;
   unsigned char CXCLR, TIA_2D, TIA_2E, TIA_2F;
   unsigned char TIA_30, TIA_31, TIA_32, TIA_33;
   unsigned char TIA_34, TIA_35, TIA_36, TIA_37;
   unsigned char TIA_38, TIA_39, TIA_3A, TIA_3B;
   unsigned char TIA_3C, TIA_3D, TIA_3E, TIA_3F;
};

#define TIA (*(struct tia_s *) 0x00)

#endif

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>
#include <string.h>

#include <conio.h>

#include <c128.h>

#include "membank128.h"

#include "env.h"

#pragma rodata-name ("APPCONST")
char magic[]="brainstm000";
static char filename [24];

#pragma bss-name ("SPRBSS")
unsigned char file_error()
{
	static char e[32]; static int i; static unsigned char c;
	cbm_close (1);
	cbm_open (10,8,15,0);
	cbm_k_chkin(10);
	for (i=0; (e[i]=cbm_k_basin())!=13; ++i);
	e[i]=0;
	cbm_k_clrch();
	cbm_close (10);
	puts ("Error accessing drive:");
	puts (e);
	puts ("Press Y to retry or N to cancel...");
	while (1) {
		c=cgetc();
		if (c=='y') return 1;
		if (c=='n') return 0;
	}
}
void file_save ()
{
	unsigned i;
	static char f[17];
retry:
	clrscr();
	puts ("Type in name of file:");
	if (GetInput(f, 17))
	{
		strcpy (filename, "@:");
		strcat (filename, f);
		strcat (filename, ",s");
		cbm_open (1,8,CBM_WRITE, filename);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		cbm_write (1, magic, strlen(magic)-1);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		cbm_write (1, &numwords, 2);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		for (i=0; i<numwords; ++i) {
			cbm_write (1, &words[i], sizeof(struct word));
			if (cbm_k_readst()) {file_error(); return;}
		}
		cbm_close (1);
	}
}
void file_load ()
{
	unsigned i;
	static char f[17];
retry:
	clrscr();
	puts ("Type in name of file:");
	if (GetInput(f, 17))
	{
		strcpy (filename, f);
		strcat (filename, ",s");
		cbm_open (1,8,CBM_READ, filename);
		cbm_read (1, f, strlen(magic)-1);
		if (cbm_k_readst()) {if (file_error()) goto retry; return;}
		if (memcmp(f, magic, strlen(magic)-1)){
			cbm_close (1);
			puts ("Error loading file: it is possibly corrupt.");
			puts ("press any key to continue...");
			cgetc();
			return;			
		}
		memset (&numparts, 0, sizeof(numparts));
		cbm_read (1, &numwords, 2);
		for (i=0; i<numwords; ++i)
		{
			cbm_read (1, &words[i], sizeof(struct word));
			if (cbm_k_readst()&0xBF) {if (file_error()) goto retry; return;}
			switch (words[i].s) {
			case 0: numparts.nouns++; break;
			case 1: numparts.verbs++; break;
			case 2: numparts.adj++; break;
			case 3: numparts.adv++; break;
			}
		}
		cbm_close (1);
	}
}
